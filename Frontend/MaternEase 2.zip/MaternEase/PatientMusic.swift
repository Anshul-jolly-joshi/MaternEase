import SwiftUI
import AVFoundation

// MARK: - Audio Model
struct AudioFile: Identifiable, Decodable {
    let id: String
    let filename: String
    let filepath: String
}

// MARK: - Audio ViewModel
class AudioViewModel: ObservableObject {
    @Published var audioFiles: [AudioFile] = []

    func fetchAudios() {
        guard let url = URL(string: "http://localhost/pregbackend/audiolist.php") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data {
                do {
                    let decoded = try JSONDecoder().decode([AudioFile].self, from: data)
                    DispatchQueue.main.async {
                        self.audioFiles = decoded
                    }
                } catch {
                    print("Decoding error: \(error)")
                }
            } else if let error = error {
                print("Error fetching audios: \(error.localizedDescription)")
            }
        }.resume()
    }
}

// MARK: - Audio Player
class AudioPlayer: ObservableObject {
    private var player: AVPlayer?

    func playAudio(url: String) {
        guard let audioURL = URL(string: url) else {
            print("Invalid audio URL")
            return
        }
        player = AVPlayer(url: audioURL)
        player?.play()
    }

    func pauseAudio() {
        player?.pause()
    }
}

// MARK: - Music Card View
struct MusicCard: View {
    var audio: AudioFile
    @State private var isFavorite = false
    @State private var isPlaying = false
    @ObservedObject var audioPlayer = AudioPlayer()

    var body: some View {
        VStack(alignment: .leading) {
            Text(audio.filename)
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(.black)

            HStack {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .foregroundColor(isFavorite ? .red : .black)
                    .onTapGesture {
                        isFavorite.toggle()
                    }

                Spacer()

                Image(systemName: "backward.fill")

                Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                    .onTapGesture {
                        isPlaying.toggle()
                        if isPlaying {
                            audioPlayer.playAudio(url: audio.filepath)
                        } else {
                            audioPlayer.pauseAudio()
                        }
                    }

                Image(systemName: "forward.fill")
            }
            .font(.title3)
            .padding(.top, 10)
        }
        .padding()
        .background(Color(red: 1, green: 0.55, blue: 0.58))
        .cornerRadius(20)
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.black.opacity(0.3), lineWidth: 0.5)
        )
    }
}

// MARK: - Main Patient Music View
struct PatientMusic: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = AudioViewModel()

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Button(action: {
                    dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.title)
                        .padding(.leading)
                        .foregroundColor(.black)
                }
                Spacer()

                Image("mother") // Replace with your asset name
                    .resizable()
                    .scaledToFill()
                    .frame(width: 90, height: 90)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
                    .offset(x: -30, y: 58)
            }

            Text("Musics")
                .font(.system(size: 30, weight: .medium))
                .bold()
                .padding(.leading)

            ScrollView {
                VStack(spacing: 20) {
                    ForEach(viewModel.audioFiles) { audio in
                        MusicCard(audio: audio)
                    }
                }
                .padding(.horizontal)
            }

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.99, green: 1, blue: 1))
        .navigationBarHidden(true)
        .onAppear {
            viewModel.fetchAudios()
        }
    }
}

// MARK: - Preview
struct PatientMusic_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            PatientMusic()
        }
    }
}

