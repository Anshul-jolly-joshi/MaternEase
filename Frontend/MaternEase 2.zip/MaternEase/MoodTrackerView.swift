import SwiftUI
import Charts


struct MoodEntry: Identifiable, Codable {
    var id = UUID()
    let date: Date
    let mood: MoodType
    let note: String
}


enum MoodType: String, CaseIterable, Codable {
    case happy = "😊"
    case neutral = "😐"
    case sad = "😢"
    case stressed = "😖"
    case excited = "🤩"
    case angry = "😡"
    case tired = "🥱"
    case relaxed = "😌"
    case love = "😍"
    case anxious = "😰"
}


class MoodViewModel: ObservableObject {
    @Published var moods: [MoodEntry] = []
    
    private var sno: String {
        UserDefaults.standard.string(forKey: "sno") ?? ""
    }

    init() {
        loadMoods()
    }

    func addMood(_ mood: MoodType, note: String) {
        let newMood = MoodEntry(date: Date(), mood: mood, note: note)
        moods.append(newMood)
        saveMoods()
    }

    func saveMoods() {
        if let encoded = try? JSONEncoder().encode(moods) {
            UserDefaults.standard.set(encoded, forKey: "moodEntries_\(sno)")
        }
    }

    func loadMoods() {
        if let savedData = UserDefaults.standard.data(forKey: "moodEntries_\(sno)"),
           let decoded = try? JSONDecoder().decode([MoodEntry].self, from: savedData) {
            moods = decoded
        }
    }
}


struct MoodTrackerView: View {
    @Environment(\.presentationMode) var presentationMode
    @StateObject private var moodViewModel = MoodViewModel()
    @State private var selectedMood: MoodType = .happy
    @State private var moodNote: String = ""
    
    var body: some View {
        NavigationView {
            VStack {
                Text("How are you feeling today?")
                    .font(.title2)
                    .padding()
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(MoodType.allCases, id: \.self) { mood in
                            Button(action: {
                                selectedMood = mood
                            }) {
                                Text(mood.rawValue)
                                    .font(.largeTitle)
                                    .padding()
                                    .background(selectedMood == mood ? Color.blue.opacity(0.3) : Color.gray.opacity(0.2))
                                    .clipShape(Circle())
                            }
                        }
                    }
                    .padding()
                }
                
                TextField("Add a note (optional)", text: $moodNote)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Button("Save Mood") {
                    moodViewModel.addMood(selectedMood, note: moodNote)
                    moodNote = ""
                }
                .padding()
                .buttonStyle(.borderedProminent)
                
                List(moodViewModel.moods.reversed()) { entry in
                    HStack {
                        Text(entry.mood.rawValue)
                            .font(.title)
                        VStack(alignment: .leading) {
                            Text(entry.date, style: .date)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                            if !entry.note.isEmpty {
                                Text("📝 \(entry.note)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                }

                Spacer()
            }
            .navigationTitle("Mood Tracker")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: MoodChartView(moodViewModel: moodViewModel)) {
                        Label("Graph", systemImage: "chart.bar.xaxis")
                    }
                }
            }
            .navigationBarBackButtonHidden(true)
        }
        .navigationBarHidden(true)
    }
}


struct MoodChartView: View {
    @ObservedObject var moodViewModel: MoodViewModel
    
    var body: some View {
        if #available(iOS 16.0, *) {
            VStack {
                Text("Mood Trends")
                    .font(.title2)
                    .padding()
                
                if moodViewModel.moods.isEmpty {
                    Text("No mood data yet! Add some moods to see trends.")
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    Chart {
                        ForEach(moodViewModel.moods) { mood in
                            BarMark(
                                x: .value("Date", mood.date, unit: .day),
                                y: .value("Mood", moodIndex(mood.mood))
                            )
                            .foregroundStyle(by: .value("Mood", mood.mood.rawValue))
                        }
                    }
                    .chartYAxis {
                        AxisMarks(values: moodYValues()) { val in
                            AxisGridLine()
                            AxisTick()
                            AxisValueLabel()
                        }
                    }
                    .chartXScale(range: .plotDimension(padding: 10))
                    .frame(height: 300)
                    .padding()
                }
            }
            .navigationTitle("Mood Analysis")
        } else {
            Text("Charts require iOS 16.0 or later.")
                .foregroundColor(.red)
                .padding()
        }
    }
    
    // Assign numeric values for moods
    func moodIndex(_ mood: MoodType) -> Int {
        switch mood {
        case .happy: return 5
        case .excited: return 4
        case .relaxed: return 6
        case .love: return 7
        case .neutral: return 3
        case .tired: return 2
        case .sad: return 1
        case .stressed: return 0
        case .angry: return -1
        case .anxious: return -2
        }
    }
    
    func moodYValues() -> [Int] {
        return [-2, -1, 0, 1, 2, 3, 4, 5, 6, 7]
    }
}

// MARK: - Preview
#Preview {
    MoodTrackerView()
}

