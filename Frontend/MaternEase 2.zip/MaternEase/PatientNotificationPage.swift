import SwiftUI

struct PatientNotificationPage: View {
    @Environment(\.dismiss) private var dismiss // Enables pop navigation

    var body: some View {
        VStack {
            // Top Navigation Bar
            HStack {
                Button(action: {
                    dismiss() // Pop the view back to PatientHomePage
                }) {
                    Image(systemName: "chevron.left")
                        .font(.title)
                        .foregroundColor(.black)
                }
                Spacer()
                Text("Notification")
                    .font(.system(size: 30, weight: .medium))
                    .foregroundColor(.black)
                Spacer()
            }
            .padding()
            
            // Move notification cards higher
            VStack(spacing: 25) {
                NotificationCard(text: "It's time to take your test", buttonText: "Take")
                NotificationCardWithImage(text: "Sorry your streak is broken")
            }
            .padding()
            .frame(maxHeight: .infinity, alignment: .top) // Aligns content at the top
        }
        .background(Color.white)
        .ignoresSafeArea(edges: .bottom) // Prevents extra padding at the bottom
        .navigationBarHidden(true)
    }
}

// Notification Card with Button
struct NotificationCard: View {
    var text: String
    var buttonText: String
    
    var body: some View {
        HStack {
            Text(text)
                .font(.system(size: 20, weight: .medium))
                .foregroundColor(.black)
                .padding()

            Spacer()

            Button(action: {}) {
                Text(buttonText)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.black)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(20)
            }
            .padding()
        }
        .frame(maxWidth: .infinity, minHeight: 60)
        .background(Color(red: 1, green: 0.55, blue: 0.58))
        .cornerRadius(25)
        
    }
    
}

// Notification Card with Image
struct NotificationCardWithImage: View {
    var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "flame.fill") // Replace with actual image
                .resizable()
                .frame(width: 60, height: 60)
                .padding()

            Text(text)
                .font(.system(size: 20, weight: .medium))
                .foregroundColor(.black)
                .padding()

            Spacer()
        }
        .frame(maxWidth: .infinity, minHeight: 80)
        .background(Color(red: 1, green: 0.55, blue: 0.58))
        .cornerRadius(25)
    }
}

struct PatientNotificationPage_Previews: PreviewProvider {
    static var previews: some View {
        PatientNotificationPage()
    }
}

