import SwiftUI

struct DoctorHomePage: View {
    @State private var searchText = ""
    @State private var patients: [PatientListData] = [] // Update to match your patient data type
    
    var body: some View {
        VStack(spacing: 0) {
            // Top Header Section
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color(red: 1.0, green: 0.5, blue: 0.5), Color(red: 0.9, green: 0.3, blue: 0.4)]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .frame(height: 160)
                    .ignoresSafeArea(edges: .top)
                
                VStack(spacing: 50) {
                    HStack {
                        Image(systemName: "person.crop.circle.fill")
                            .foregroundColor(.white)
                            .font(.system(size: 40, weight: .bold))
                        
                        NavigationLink(destination: DoctorMenu()) {
                            Text("Doctor")
                                .font(.system(size: 34, weight: .bold))
                                .foregroundColor(.white)
                        }

                        Spacer()
                        
                        NavigationLink(destination: DoctorLoginView()) {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                .foregroundColor(.white)
                                .font(.system(size: 24))
                        }
                    }
                    .padding(.horizontal)
                    
                    // Search Bar
                    TextField("Search Patients", text: $searchText)
                        .padding(10)
                        .background(Color.gray.opacity(0.6))
                        .cornerRadius(10)
                        .padding(.horizontal, 20)
                }
                .padding(.top, 10)
            }
            .frame(height: 150)
            .padding(.bottom, 10)

            // Scrollable List of Patients
            ScrollView {
                VStack(spacing: 15) {
                    ForEach(patients.indices, id: \.self) { index in
                        PatientCard(patient: patients[index])
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
            }
            
            // Bottom Navigation Bar
            HStack {
                NavigationLink(destination: DoctorDetails()) {
                    BottomNavItem(icon: "stethoscope", isActive: true)
                }
                
                Spacer()
                
                Button(action: {}) {
                    BottomNavItem(icon: "house.fill", isActive: true)
                }
                
                Spacer()
                
                NavigationLink(destination: DoctorNotificationPage()) {
                    BottomNavItem(icon: "bell.fill", isActive: true)
                }
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(25)
            .padding(.horizontal, 30)
            .padding(.bottom, 20)
            .shadow(radius: 5)
        }
        .background(Color.white)
        .ignoresSafeArea(edges: .bottom)
        .navigationBarHidden(true)
        .onAppear {
            // Fetch patients when the view appears
            fetchPatients()
        }
    }
    
    // Filtered patient list based on search input
    private var filteredPatients: [PatientListData] {
        patients.filter { patient in
            searchText.isEmpty || patient.username.localizedCaseInsensitiveContains(searchText)
        }
    }
    
    // Fetch patients from the backend
    private func fetchPatients() {
        guard let url = URL(string: "http://localhost/pregbackend/patientlist.php") else {
            print("Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching patients: \(error)")
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    let response = try decoder.decode(PatientListModel.self, from: data)
                    DispatchQueue.main.async {
                        self.patients = response.data
                    }
                } catch {
                    print("Error decoding patients: \(error)")
                }
            }
        }.resume()
    }
}

// ✅ Patient Card
struct PatientCard: View {
    var patient: PatientListData
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "person.crop.circle.fill")
                    .foregroundColor(.white)
                    .font(.title2)
                Text(patient.firstname)
                    .foregroundColor(.white)
                    .font(.headline)
                    .fontWeight(.semibold)
                Spacer()
            }
            HStack(spacing: 12) {
                Button(action: {}) {
                    Text("See Statistics")
                        .font(.subheadline)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 14)
                        .background(Color.gray.opacity(0.4))
                        .cornerRadius(10)
                        .foregroundColor(.white)
                }
                Button(action: {}) {
                    Text("Update profile")
                        .font(.subheadline)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 14)
                        .background(Color.gray.opacity(0.4))
                        .cornerRadius(10)
                        .foregroundColor(.white)
                }
                Spacer()
            }
        }
        .padding()
        .background(Color(red: 1.0, green: 0.5, blue: 0.5))
        .cornerRadius(25)
        .shadow(color: Color.black.opacity(0.2), radius: 6, x: 0, y: 3)
    }
}

// ✅ Bottom Navigation Bar
struct BottomNavItem: View {
    var icon: String
    var isActive: Bool = false
    
    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(isActive ? Color.black : Color.gray)
        }
    }
}

//// ✅ Patient Model
//struct PatientInfo: Identifiable, Decodable {
//    var id: Int
//    var name: String
//    var dp: String? // Optional profile image data
//}
//
//// ✅ Patient Response
//struct PatientResponse: Decodable {
//    var status: String
//    var message: String
//    var data: [PatientInfo]
//}

// ✅ Preview
struct DoctorHomePage_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            DoctorHomePage()
        }
        .previewDevice("iPhone 13 Pro Max")
    }
}

