import SwiftUI

struct DoctorLoginView: View {
    @State private var userID: String = ""
    @State private var password: String = ""
    @State private var isSecure: Bool = true
    @State private var navigateToHome = false
    @State private var errorMessage: String?
    @State private var isNavigatingToHomePageView = false

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color(red: 244/255, green: 226/255, blue: 226/255), Color(red: 210/255, green: 135/255, blue: 137/255)]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                Image("baby")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 130, height: 130)
                    .padding(.top, 10)

                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Hello, Doctor!")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        Text("Sign in to access your dashboard")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Doctor ID")
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        TextField("Enter your Doctor ID", text: $userID)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                            )
                    }
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Password")
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        HStack {
                            if isSecure {
                                SecureField("Enter your password", text: $password)
                            } else {
                                TextField("Enter your password", text: $password)
                            }
                            Button(action: {
                                isSecure.toggle()
                            }) {
                                Image(systemName: isSecure ? "eye.slash" : "eye")
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                        )
                    }
                    
                    if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.caption)
                    }
                    
                    Button(action: {
                        loginDoctor()
                    }) {
                        Text("Sign in")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(LinearGradient(gradient: Gradient(colors: [Color(red: 141/255, green: 64/255, blue: 66/255), Color(red: 176/255, green: 90/255, blue: 91/255)]), startPoint: .leading, endPoint: .trailing))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 4)
                    }

                    NavigationLink(destination: DoctorHomePage()
                        .navigationBarBackButtonHidden(true)
                        .navigationBarHidden(true),
                        isActive: $navigateToHome) {
                        EmptyView()
                    }
                }
                .padding(25)
                .background(Color.white)
                .cornerRadius(30)
                .padding(.horizontal, 30)
                .padding(.top, 10)
                .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 5)
                
                Spacer()
            }

            // Back Button - Positioned Outside the White Box, Centered Near the Bottom
            VStack {
                Spacer()
                
                Button(action: {
                    isNavigatingToHomePageView = true
                }) {
                    Circle()
                        .fill(Color.white)
                        .frame(width: 40, height: 40)
                        .shadow(color: .gray.opacity(0.3), radius: 3, x: 0, y: 2)
                        .overlay(
                            Image(systemName: "arrow.left")
                                .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        )
                }
                .padding(.bottom, 30) // Adjust this for exact position

                NavigationLink(destination: HomePageView()
                    .navigationBarBackButtonHidden(true)
                    .transition(.move(edge: .trailing)),
                    isActive: $isNavigatingToHomePageView) {
                    EmptyView()
                }
            }
        }
        .navigationBarHidden(true)
    }
    
    func loginDoctor() {
        guard let url = URL(string:"http://localhost/pregbackend/docterlogin.php") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let bodyData = "username=\(userID)&password=\(password)"
        request.httpBody = bodyData.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    self.errorMessage = "Network error: \(error.localizedDescription)"
                    return
                }
                
                guard let data = data else {
                    self.errorMessage = "Invalid response from server"
                    return
                }
                
                do {
                    let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                    if let status = jsonResponse?["status"] as? String, status == "true" {
                        self.navigateToHome = true
                    } else {
                        self.errorMessage = jsonResponse?["message"] as? String ?? "Login failed"
                    }
                } catch {
                    self.errorMessage = "Parsing error"
                }
            }
        }.resume()
    }
}

// Preview
struct DoctorLoginView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            DoctorLoginView()
        }
    }
}

