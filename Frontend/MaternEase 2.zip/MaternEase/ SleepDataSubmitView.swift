import SwiftUI

struct SleepDataSubmitView: View {
    @State private var sleepDate = Date()
    @State private var sleepDuration = ""
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        ZStack {
            // Background Gradient
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.8)]),
                           startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                Text("Enter Sleep Data")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.bottom, 10)
                
                VStack(spacing: 20) {
                    DatePicker("Sleep Date", selection: $sleepDate, displayedComponents: .date)
                        .datePickerStyle(GraphicalDatePickerStyle())
                        .padding()
                        .background(Color.white.opacity(0.9))
                        .cornerRadius(12)
                        .shadow(radius: 5)

                    TextField("Enter Sleep Duration (in hours)", text: $sleepDuration)
                        .keyboardType(.decimalPad)
                        .padding()
                        .background(Color.white.opacity(0.9))
                        .cornerRadius(12)
                        .shadow(radius: 5)

                    Button(action: submitData) {
                        Text("Submit")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.teal]), startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(12)
                            .shadow(radius: 5)
                    }
                    .padding(.horizontal, 30)
                }
                .padding()
                .background(RoundedRectangle(cornerRadius: 15).fill(Color.white.opacity(0.95)).shadow(radius: 5))
                .padding()
            }
            .padding()
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Message"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
    
    func submitData() {
        alertMessage = "Data submitted successfully!"
        showAlert = true
    }
}

struct SleepDataSubmitView_Previews: PreviewProvider {
    static var previews: some View {
        SleepDataSubmitView()
    }
}

