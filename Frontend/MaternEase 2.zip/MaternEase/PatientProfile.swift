import SwiftUI

struct ProfilePage: View {
    @Environment(\.dismiss) private var dismiss // Enables pop navigation
    @State private var navigateToLogin = false // State for Log Out navigation
    
    var body: some View {
        ZStack {
            // Background Gradient
            LinearGradient(
                gradient: Gradient(colors: [Color.pink.opacity(0.3), Color.white]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            VStack {
                // Back Button to navigate back
                HStack {
                    Button(action: {
                        dismiss() // Pop back to the previous screen (PatientDashboard)
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.title)
                            .foregroundColor(.black)
                    }
                    Spacer()
                }
                .padding([.top, .leading])
                
                Spacer()
                
                // Centered Content
                VStack(spacing: 30) {
                    // Profile Section
                    VStack(spacing: 12) {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .frame(width: 120, height: 120)
                            .foregroundColor(.pink)
                        
                        Text("User")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Text("@User123")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    
                    // Right-side baby image (Replace with actual image)
                    HStack {
                        Spacer()
                        Image("person.circle.fill")
                            .resizable()
                            .frame(width: 90, height: 90)
                            .padding(.trailing)
                    }

                    // Action Buttons
                    VStack(spacing: 25) {
                        NavigationLink(destination: ViewDetails()) {
                            ProfileButton(title: "View Details")
                        }
                        
                        NavigationLink(destination: PasswordChange()) {
                            ProfileButton(title: "Change Password")
                        }

                        // ✅ "Log Out" button now properly navigates to PatientLoginView
                        Button(action: {
                            navigateToLogin = true
                        }) {
                            ProfileButton(title: "Log Out")
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 40)
                }
                
                Spacer()
            }
        }
        .navigationBarHidden(true) // Hide default navigation bar
        .background(
            NavigationLink(destination: PatientLoginView(), isActive: $navigateToLogin) {
                EmptyView()
            }
        )
    }
}

// MARK: - Profile Button Component
struct ProfileButton: View {
    var title: String
    var body: some View {
        Text(title)
            .font(.title3)
            .fontWeight(.bold)
            .foregroundColor(.black)
            .frame(maxWidth: .infinity)
            .frame(height: 60)
            .background(Color(red: 1.0, green: 0.6, blue: 0.6))
            .cornerRadius(15)
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(Color.black, lineWidth: 1.5)
            )
    }
}

// MARK: - Preview
struct ProfilePage_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ProfilePage()
        }
        .previewDevice("iPhone 13 Pro Max")
    }
}

