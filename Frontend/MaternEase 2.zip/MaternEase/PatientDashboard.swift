import SwiftUI

import SwiftUI

struct PatientDashboard: View {
    @State private var navigateToHome = false
    @State private var navigateToLogin = false
    @State private var navigateToProfile = false
    @State private var navigateToMyTestScore = false
    @State private var navigateToTracker = false  // State to navigate to TrackerView

    var body: some View {
        ZStack {
            Image("women.png")
                .resizable()
                .scaledToFill()
                .blur(radius: 5)
                .ignoresSafeArea()
                .opacity(0.85)
            
            VStack {
                HStack {
                    Spacer()
                    Button(action: {
                        withAnimation(.easeInOut) {
                            navigateToHome = true
                        }
                    })
                    {
                        ZStack {
                            Circle()
                                .fill(Color.white)
                                .frame(width: 60, height: 60)
                                .shadow(color: Color.black.opacity(0.4), radius: 5, x: 2, y: 2)
                                .overlay(
                                    Circle()
                                        .stroke(Color(red: 0.6, green: 0.2, blue: 0.25), lineWidth: 3)
                                )
                            
                            Image(systemName: "arrow.right")
                                .foregroundColor(Color(red: 0.6, green: 0.2, blue: 0.25))
                                .font(.system(size: 28, weight: .bold))
                        }
                    }
                    .padding(.top, 40)
                    .padding(.trailing, 25)
                }
                Spacer()
            }
            
            VStack {
                Spacer()
                
                VStack(spacing: 35) {
                    Button(action: {
                        withAnimation(.easeInOut) {
                            navigateToProfile = true
                        }
                    }) {
                        MenuItemView(label: "Profile", systemImage: "person.circle.fill")
                    }
                    
                    Divider().background(Color.black)
                    
                    Button(action: {
                        withAnimation(.easeInOut) {
                            navigateToMyTestScore = true
                        }
                    }) {
                        MenuItemView(label: "AI Chatbot", systemImage: "bubble.left.and.bubble.right.fill")
                    }
                    
                    Divider().background(Color.black)
                    
                    Button(action: {
                        withAnimation(.easeInOut) {
                            navigateToTracker = true
                        }
                    }) {
                        MenuItemView(label: "Tracker", systemImage: "figure.walk")
                    }
                    
                    Divider().background(Color.black)
                    
                    // ✅ Fixed Log Out Button
                    Button(action: {
                        withAnimation(.easeInOut) {
                            navigateToLogin = true
                        }
                    }) {
                        MenuItemView(label: "Log Out", systemImage: "arrowshape.turn.up.left.fill")
                    }
                }
                .padding(35)
                .background(Color(red: 1, green: 0.55, blue: 0.58).opacity(0.9))
                .cornerRadius(35)
                .overlay(
                    RoundedRectangle(cornerRadius: 35)
                        .stroke(Color(red: 0.6, green: 0.2, blue: 0.25), lineWidth: 4)
                )
                .padding(.horizontal, 30)
                .frame(maxWidth: 400)
                
                Spacer()
            }
            
            // ✅ Hidden NavigationLinks (Fix for iOS 15 and below)
            NavigationLink(destination: PatientLoginView(), isActive: $navigateToLogin) { EmptyView() }
            NavigationLink(destination: ProfilePage(), isActive: $navigateToProfile) { EmptyView() }
            NavigationLink(destination: ChatBotView(), isActive: $navigateToMyTestScore) { EmptyView() }
            NavigationLink(destination: TrackerView(), isActive: $navigateToTracker) { EmptyView() }
            
        }
        .navigationBarBackButtonHidden(true)
    }
}



struct MenuItemView: View {
    var label: String
    var systemImage: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(.custom("Poppins", size: 24).weight(.semibold))
                .foregroundColor(.black)
            Spacer()
            Image(systemName: systemImage)
                .resizable()
                .scaledToFit()
                .frame(width: 30, height: 30)
                .foregroundColor(.black)
                .padding(.trailing, 5)
        }
        .padding(.horizontal, 5)
    }
}

struct PatientDashboard_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            PatientDashboard()
        }
    }
}
