import SwiftUI

struct GuardianHomePage: View {
    @State private var navigateToLogin = false  // State for navigation

    var body: some View {
        NavigationView {
            ZStack {
                // Background Gradient
                LinearGradient(
                    gradient: Gradient(colors: [Color.pink.opacity(0.2), Color.pink.opacity(0.6)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .edgesIgnoringSafeArea(.all)

                VStack(spacing: 20) {
                    Text("Guardian Home")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.top, 20)
                        .foregroundColor(.white)

                    // Mood Tracker - navigates to MoodTrackerView
                    NavigationLink(destination: MoodTrackerView()) {
                        TrackerCard(title: "Mood Tracker", icon: "face.smiling.fill", color: .blue)
                    }

                    // Sleep Tracker - static button, no navigation
                    NavigationLink(destination: SleepChartView()) {
                        TrackerCard(title: "Sleep Tracker", icon: "bed.double.fill", color: .purple)
                    }



                    Spacer()

                    // Navigation to PatientDetailsView
                    NavigationLink(destination: PatientDetailsView()) {
                        Text("View Patient Details")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.red)
                            .cornerRadius(10)
                            .padding(.horizontal, 20)
                    }

                    Spacer()
                }
                .padding()
                .navigationBarItems(
                    trailing: Button(action: {
                        withAnimation {
                            navigateToLogin = true  // Trigger navigation
                        }
                    }) {
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                            .foregroundColor(.red)
                    }
                )
                .background(
                    NavigationLink(
                        destination: GuardianLoginView().transition(.move(edge: .trailing)),
                        isActive: $navigateToLogin
                    ) { EmptyView() }
                )
                .navigationBarHidden(false)
            }
        }
    }
}

struct TrackerCard: View {
    var title: String
    var icon: String
    var color: Color

    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.largeTitle)
                .foregroundColor(.white)
                .padding()

            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)

            Spacer()
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(color)
        .cornerRadius(15)
        .shadow(radius: 5)
        .padding(.horizontal, 20)
    }
}

struct GuardianHomePage_Previews: PreviewProvider {
    static var previews: some View {
        GuardianHomePage()
    }
}

