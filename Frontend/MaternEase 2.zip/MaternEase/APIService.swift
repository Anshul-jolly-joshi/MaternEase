import Foundation

struct APIService {
    static let baseURL = "http://localhost/pregbackend"

    static func login(username: String, password: String, completion: @escaping (Result<UserData, APIError>) -> Void) {
        guard let url = URL(string: "\(baseURL)/patientlogin.php") else {
            completion(.failure(.invalidURL))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        // Encode parameters to avoid issues with special characters
        let encodedUsername = username.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let encodedPassword = password.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let bodyParameters = "username=\(encodedUsername)&password=\(encodedPassword)"
        request.httpBody = bodyParameters.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(.networkError(error.localizedDescription)))
                return
            }

            guard let data = data else {
                completion(.failure(.noData))
                return
            }

            // Debugging response from server
            if let responseString = String(data: data, encoding: .utf8) {
                print("🔴 Raw Response: \(responseString)")
            }

            do {
                let decodedResponse = try JSONDecoder().decode(LoginResponse.self, from: data)
                if decodedResponse.status == "true", let user = decodedResponse.data?.first {
                    completion(.success(user))
                } else {
                    completion(.failure(.serverError(decodedResponse.message)))
                }
            } catch {
                print("❌ Decoding Error: \(error.localizedDescription)")
                if let responseString = String(data: data, encoding: .utf8) {
                    print("🔴 Raw Response (Decoding Failed): \(responseString)")
                }
                completion(.failure(.decodingError))
            }
        }.resume()
    }
}

// Define API Errors
enum APIError: Error, LocalizedError {
    case invalidURL
    case networkError(String)
    case noData
    case decodingError
    case serverError(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid API URL."
        case .networkError(let message):
            return "Network Error: \(message)"
        case .noData:
            return "No data received from server."
        case .decodingError:
            return "Failed to decode response from server."
        case .serverError(let message):
            return message
        }
    }
}

// Define Response Structures
struct LoginResponse: Codable {
    let status: String
    let message: String
    let data: [UserData]?
}

struct UserData: Codable {
    let username: String
    let email: String?
    let mobile: String?
    let id: String?
}

