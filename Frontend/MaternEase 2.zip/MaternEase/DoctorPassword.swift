import SwiftUI

struct DoctorPassword: View {
    @Environment(\.dismiss) var dismiss
    @State private var userId: String = ""
    @State private var oldPassword: String = ""
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    @State private var showPasswordUpdated: Bool = false
    @State private var navigateToHome: Bool = false
    @State private var errorMessage: String?

    var body: some View {
        if #available(iOS 16.0, *) {
            NavigationStack {
                VStack {
                    // Back Button
                    HStack {
                        Button(action: {
                            dismiss()
                        }) {
                            Image(systemName: "chevron.left")
                                .font(.title)
                                .foregroundColor(.black)
                        }
                        .padding(.leading)
                        
                        Spacer()
                    }
                    .frame(height: 50)
                    
                    // Success message
                    if showPasswordUpdated {
                        Text("Password updated successfully!")
                            .foregroundColor(.green)
                            .font(.headline)
                            .padding(.top, 10)
                    }
                    
                    // Error message
                    if let error = errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                            .font(.subheadline)
                            .padding(.top, 5)
                    }
                    
                    Spacer()
                    
                    Image(systemName: "person.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 80)
                    
                    Text("Edit Password")
                        .font(.title)
                        .bold()
                        .foregroundColor(.black)
                        .padding(.bottom, 20)
                    
                    VStack(alignment: .leading, spacing: 15) {
                        Text("User ID")
                            .font(.headline)
                        TextField("Enter User ID", text: $userId)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        
                        Text("Old Password")
                            .font(.headline)
                        SecureField("Enter Old Password", text: $oldPassword)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        
                        Text("New Password")
                            .font(.headline)
                        SecureField("Enter New Password", text: $newPassword)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        
                        Text("Confirm Password")
                            .font(.headline)
                        SecureField("Confirm Password", text: $confirmPassword)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                    .padding(.horizontal, 20)
                    
                    Spacer()
                    
                    Button(action: {
                        changePassword()
                    }) {
                        Text("Change Password")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.brown)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .padding(.horizontal, 20)
                    }
                    
                    // Navigate to DoctorHomePage
                    NavigationLink(destination: DoctorHomePage(), isActive: $navigateToHome) {
                        EmptyView()
                    }
                    
                    Spacer()
                }
                .padding()
                .background(Color.pink.opacity(0.5).edgesIgnoringSafeArea(.all))
                .navigationBarHidden(true)
            }
        } else {
            // Fallback on earlier versions
        }
    }

    // MARK: - Password Change Logic
    func changePassword() {
        guard !userId.isEmpty, !oldPassword.isEmpty, !newPassword.isEmpty, !confirmPassword.isEmpty else {
            errorMessage = "Please fill in all fields."
            return
        }

        guard newPassword == confirmPassword else {
            errorMessage = "Passwords do not match."
            return
        }

        guard let url = URL(string: "http://localhost/pregbackend/doctorchangepassword.php") else {
            errorMessage = "Invalid URL."
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let postString = "username=\(userId)&old_password=\(oldPassword)&new_password=\(newPassword)"
        request.httpBody = postString.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    errorMessage = "Network error: \(error.localizedDescription)"
                }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    errorMessage = "No response from server."
                }
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let status = json["status"] as? String {
                    DispatchQueue.main.async {
                        if status == "true" {
                            showPasswordUpdated = true
                            errorMessage = nil

                            // Navigate after 2 seconds
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                                navigateToHome = true
                            }
                        } else {
                            errorMessage = json["message"] as? String ?? "Password update failed."
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        errorMessage = "Unexpected server response."
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    errorMessage = "Failed to parse response."
                }
            }
        }.resume()
    }
}

// MARK: - Preview
struct DoctorPassword_Previews: PreviewProvider {
    static var previews: some View {
        DoctorPassword()
    }
}

