import SwiftUI
struct GuardianLoginView: View {
    @State private var userID: String = ""
    @State private var password: String = ""
    @State private var isSecure: Bool = true
    @State private var isNavigatingToHome = false
    @State private var isNavigatingToHomePageView = false
    @State private var loginMessage: String = ""

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color(red: 244/255, green: 226/255, blue: 226/255), Color(red: 210/255, green: 135/255, blue: 137/255)]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                Image("baby")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 130, height: 130)
                    .padding(.top, 10)

                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Hello, Guardian!")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        Text("Sign in to access your dashboard")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        Text("Guardian ID")
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        TextField("Enter your Guardian ID", text: $userID)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                            )
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        Text("Password")
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        HStack {
                            Group {
                                if isSecure {
                                    SecureField("Enter your password", text: $password)
                                } else {
                                    TextField("Enter your password", text: $password)
                                }
                            }
                            Button(action: {
                                isSecure.toggle()
                            }) {
                                Image(systemName: isSecure ? "eye.slash" : "eye")
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                        )
                    }

                    if !loginMessage.isEmpty {
                        Text(loginMessage)
                            .foregroundColor(.red)
                            .font(.subheadline)
                    }

                    Button(action: loginUser) {
                        Text("Sign in")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(LinearGradient(gradient: Gradient(colors: [Color(red: 141/255, green: 64/255, blue: 66/255), Color(red: 176/255, green: 90/255, blue: 91/255)]), startPoint: .leading, endPoint: .trailing))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 4)
                    }

                    NavigationLink(destination: GuardianHomePage()
                        .navigationBarBackButtonHidden(true)
                        .navigationBarHidden(true),
                        isActive: $isNavigatingToHome) {
                        EmptyView()
                    }
                }
                .padding(25)
                .background(Color.white)
                .cornerRadius(30)
                .padding(.horizontal, 30)
                .padding(.top, 30)
                .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 5)

                Spacer()

                // Back Button
                Button(action: {
                    isNavigatingToHomePageView = true
                }) {
                    Circle()
                        .fill(Color.white)
                        .frame(width: 40, height: 40)
                        .shadow(color: .gray.opacity(0.3), radius: 3, x: 0, y: 2)
                        .overlay(
                            Image(systemName: "arrow.left")
                                .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        )
                }
                .padding(.bottom, 25)

                NavigationLink(destination: HomePageView()
                    .navigationBarBackButtonHidden(true)
                    .transition(.move(edge: .trailing)),
                    isActive: $isNavigatingToHomePageView) {
                    EmptyView()
                }
            }
        }
        .navigationBarHidden(true)
    }

    func loginUser() {
        guard let url = URL(string: "http://localhost/pregbackend/patientlogin.php") else { return }
        let parameters: [String: String] = ["username": userID, "password": password]
        let body = parameters.map { "\($0.key)=\($0.value)" }.joined(separator: "&").data(using: .utf8)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = body
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                DispatchQueue.main.async { loginMessage = "Network error. Please try again." }
                return
            }

            do {
                print(String(data: data, encoding: .utf8))
                let loginResponse = try JSONDecoder().decode(LoginResponse.self, from: data)
                DispatchQueue.main.async {
                    if loginResponse.status == "true" {
                        UserDefaults.standard.set(loginResponse.data?.first?.id, forKey: "sno")
                        isNavigatingToHome = true
                        
                    } else {
                        loginMessage = loginResponse.message
                    }
                }
            } catch {
                DispatchQueue.main.async { loginMessage = "Invalid response. Please try again." }
            }
        }.resume()
    }
}

// Preview
struct GuardianLoginView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            GuardianLoginView()
        }
    }
}

