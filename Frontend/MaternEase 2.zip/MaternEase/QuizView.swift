import SwiftUI

// MARK: - Question Model
struct Question {
    let text: String
    let options: [String]
    let correctAnswerIndex: Int
}

// MARK: - Quiz View
struct QuizView: View {
    let questions: [Question] = [
        Question(text: "I have been able to laugh and see the funny side of things", options: [
            "As much as I always could", "Not quite so much now", "Definitely not so much now", "Not at all"
        ], correctAnswerIndex: 0),
        
        Question(text: "I have looked forward with enjoyment to things", options: [
            "As much as I ever could", "Rather less than I used to", "Definitely less than I used to", "Not at all"
        ], correctAnswerIndex: 0),
        
        Question(text: "I have blamed myself unnecessarily when things went wrong", options: [
                    "Yes, most of the time", "Yes, some of the time", "Not very often", "No, never"
                ], correctAnswerIndex: 3),
                
                Question(text: "I have felt scared or panicky for no good reason", options: [
                    "Yes, quite a lot", "Yes, sometimes", "No, not much", "No, not at all"
                ], correctAnswerIndex: 3),
                
                Question(text: "I have been anxious or worried for no good reason", options: [
                    "No, not at all", "Hardly ever", "Yes, sometimes", "Yes, very often"
                ], correctAnswerIndex: 0),
                
                Question(text: "I have been so unhappy that I have been crying", options: [
                    "Yes, most of the time", "Yes, quite often", "Only occasionally", "No, never"
                ], correctAnswerIndex: 3),
                
                Question(text: "I have been so unhappy that I have had difficulty sleeping", options: [
                    "Yes, most of the time", "Yes, sometimes", "Not very often", "Not at all"
                ], correctAnswerIndex: 3),
                
                Question(text: "Things have been getting to me", options: [
                    "Yes, most of the time I haven’t been able to cope at all",
                    "Yes, sometimes I haven’t been coping as well as usual",
                    "No, most of the time I have coped quite well",
                    "No, I have been coping as well as ever"
                ], correctAnswerIndex: 3),
                
                Question(text: "The thought of harming myself has occurred to me", options: [
                    "Yes, quite often", "Sometimes", "Hardly ever", "Never"
                ], correctAnswerIndex: 3),
                
                Question(text: "I have felt overwhelmed by my responsibilities", options: [
                    "Yes, most of the time", "Yes, sometimes", "No, not much", "No, not at all"
                ], correctAnswerIndex: 3)
    ]
    
    @State private var currentQuestionIndex = 0
    @State private var selectedAnswerIndex: Int? = nil
    @State private var score = 0
    @State private var answeredQuestions: [Int: Int] = [:] // Tracks answered questions
    @State private var showScore = false
    @Environment(\.presentationMode) var presentationMode // For navigation
    
    var body: some View {
//        NavigationView {
            ZStack {
                Color.black.opacity(0.1)
                    .ignoresSafeArea()
                
                if showScore {
                    ScoreView(score: score, total: questions.count, restartQuiz: restartQuiz, goToHome: goToHome)
                } else {
                    VStack {
                        HStack {
                            Button(action: {
                                goToHome()
                            }) {
                                Image(systemName: "chevron.left")
                                    .foregroundColor(.black)
                                    .padding()
                            }
                            Spacer()
                        }
                        
                        Text("Take Test")
                            .font(.title)
                            .bold()
                            .foregroundColor(.red)
                            .padding()
                        
                        VStack {
                            Text(questions[currentQuestionIndex].text)
                                .font(.headline)
                                .padding()
                            
                            ForEach(0..<questions[currentQuestionIndex].options.count, id: \.self) { index in
                                Button(action: {
                                    selectedAnswerIndex = index
                                }) {
                                    HStack {
                                        Text(questions[currentQuestionIndex].options[index])
                                        Spacer()
                                        if selectedAnswerIndex == index {
                                            Image(systemName: "checkmark.circle.fill")
                                                .foregroundColor(.green)
                                        }
                                    }
                                    .padding()
                                    .background(Color.white.opacity(0.8))
                                    .cornerRadius(10)
                                }
                                .padding(.horizontal)
                            }
                        }
                        .padding()
                        
                        HStack {
                            if currentQuestionIndex > 0 {
                                Button(action: {
                                    currentQuestionIndex -= 1
                                    selectedAnswerIndex = answeredQuestions[currentQuestionIndex] ?? nil
                                }) {
                                    HStack {
                                        Image(systemName: "arrow.left")
                                        Text("Back")
                                    }
                                    .font(.headline)
                                    .padding()
                                    .foregroundColor(.white)
                                    .background(Color.gray)
                                    .cornerRadius(10)
                                }
                            }
                            Spacer()
                            Button(action: {
                                if let selected = selectedAnswerIndex {
                                    if answeredQuestions[currentQuestionIndex] == nil, selected == questions[currentQuestionIndex].correctAnswerIndex {
                                        score += 1
                                    }
                                    
                                    answeredQuestions[currentQuestionIndex] = selected
                                    
                                    if currentQuestionIndex < questions.count - 1 {
                                        currentQuestionIndex += 1
                                        selectedAnswerIndex = answeredQuestions[currentQuestionIndex] ?? nil
                                    } else {
                                        showScore = true
                                    }
                                }
                            }) {
                                Text(currentQuestionIndex == questions.count - 1 ? "Submit" : "Next")
                                    .font(.headline)
                                    .padding()
                                    .foregroundColor(.white)
                                    .background(Color.red)
                                    .cornerRadius(10)
                            }
                        }
                        .padding()
                    }
                }
            }
            .navigationBarHidden(true)
//        }
        .navigationBarHidden(true)
    }
    
    func restartQuiz() {
        currentQuestionIndex = 0
        selectedAnswerIndex = nil
        score = 0
        showScore = false
        answeredQuestions.removeAll()
    }
    
    func goToHome() {
        presentationMode.wrappedValue.dismiss()
    }
}

// MARK: - Score View
struct ScoreView: View {
    var score: Int
    var total: Int
    var restartQuiz: () -> Void
    var goToHome: () -> Void
    @State private var animate = false
    
    var body: some View {
        VStack {
            Text("Your Score")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.white)
                .padding(.top, 50)
            
            Text("\(score) / \(total)")
                .font(.system(size: 40, weight: .bold))
                .foregroundColor(.yellow)
                .scaleEffect(animate ? 1.2 : 1.0)
                .animation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true), value: animate)
                .onAppear {
                    animate = true
                }
            
            Button(action: restartQuiz) {
                Text("Restart")
                    .font(.headline)
                    .padding()
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding()
            
            Button(action: goToHome) {
                Text("Go to Home")
                    .font(.headline)
                    .padding()
                    .foregroundColor(.white)
                    .background(Color.green)
                    .cornerRadius(10)
            }
            .padding(.bottom, 50)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            LinearGradient(gradient: Gradient(colors: [Color.purple, Color.blue]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
        )
    }
}

// MARK: - Preview
struct QuizView_Previews: PreviewProvider {
    static var previews: some View {
        QuizView()
    }
}

