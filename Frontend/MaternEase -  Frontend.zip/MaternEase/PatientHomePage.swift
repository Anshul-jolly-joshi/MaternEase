import SwiftUI

struct PatientHomePage: View {
    var body: some View {

            VStack(spacing: 15) {
                
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 18) {
                        Text("Hello Patient")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        HStack(alignment: .top) {
                            Image(systemName: "person.crop.circle.fill")
                                .foregroundColor(.yellow)
                            Text("How can I best help you today? Let me know by doing your daily check in.")
                                .font(.caption)
                                .padding(11)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.gray.opacity(0.8), lineWidth: 1.5)
                                )
                        }
                    }
                    Spacer()
                    
                    NavigationLink(destination: PatientDashboard()) {
                        Image(systemName: "line.horizontal.3")
                            .font(.title)
                            .foregroundColor(.black)
                            .padding(8)
                    }
                }
                .padding(.horizontal)
                
                
                Text("Daily Check In")
                    .font(.title3)
                    .fontWeight(.bold)
                    .padding(.horizontal)
                
                
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    CheckInCard(title: "How was your mood today ?", imageName: "mood")
                    CheckInCard(title: "How was your sleep last night ?", imageName: "sleep")
                    CheckInCard(title: "How it went today ?", imageName: "circle")
                    CheckInCard(title: "Track Your Sleep", imageName: "image")
                }
                .padding(.horizontal)
                .padding(.bottom, 30)
                .frame(maxHeight: .infinity)
                
                
                HStack {
                    NavigationLink(destination: QuizView()) {
                        BottomTab(icon: "doc.text", label: "Test")
                    }
                    
                    Spacer()
                    
                    NavigationLink(destination: StressReliefView()) {
                        BottomTab(icon: "leaf.fill", label: "Relax")
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        // TODO: Add action for Home tab
                    }) {
                        BottomTab(icon: "house.fill", label: "Home", isActive: true)
                    }
                    
                    Spacer()
                    
                    NavigationLink(destination: PatientNotificationPage()) {
                        BottomTab(icon: "bell.fill", label: "Reminder")
                    }

                }
                .padding()
                .background(Color(red: 1.0, green: 0.85, blue: 0.85)) // Soft pink
                .cornerRadius(20)
                .padding(.horizontal)
                .padding(.bottom, 50)
            }
            .padding(.top, 10)
            .navigationBarHidden(true)
//        }
        .navigationBarHidden(true)
        
        
    }
    
}



struct CheckInCard: View {
    var title: String
    var imageName: String
    
    var body: some View {
        VStack(spacing: 12) {
            Image(imageName)
                .resizable()
                .scaledToFit()
                .frame(height: 80)
                .padding(10)
                .background(Color.white)
                .clipShape(Circle())
                .shadow(radius: 4)
            
            Text(title)
                .multilineTextAlignment(.center)
                .font(.headline)
                .foregroundColor(.black)
                .padding(.horizontal, 8)
        }
        .frame(maxWidth: .infinity, minHeight: 180)
        .padding()
        .background(
            LinearGradient(
                gradient: Gradient(colors: [Color(red: 1.0, green: 0.7, blue: 0.7), Color(red: 1.0, green: 0.6, blue: 0.6)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.black.opacity(0.8), lineWidth: 2)
        )
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 4)
    }
}



struct BottomTab: View {
    var icon: String
    var label: String
    var isActive: Bool = false
    
    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(isActive ? Color.pink : Color.gray)
            Text(label)
                .font(.caption)
                .foregroundColor(isActive ? Color.pink : Color.gray)
        }
    }
}

// MARK: - Preview

struct PatientHomePage_Previews: PreviewProvider {
    static var previews: some View {
        PatientHomePage()
            .previewDevice("iPhone 13 Pro Max")
    }
}
