import SwiftUI

struct Message: Hashable {
    let text: String
    let isUser: Bool
}

struct ChatBotView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var messageText: String = ""
    @State private var messages: [Message] = [
        Message(text: "Hello! I'm Nova. How can I assist you today?", isUser: false)
    ]
    @State private var isTyping = false

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.pink.opacity(0.4), Color.pink]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                // 🔙 Top Bar
                HStack(spacing: 10) {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .font(.system(size: 22, weight: .bold))
                            .padding(.leading)
                    }

                    Text("Nova")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.black)

                    Spacer()
                }
                .padding(.vertical, 16)
                .background(Color.white)
                .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)

                // 💬 Chat Messages
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        ForEach(messages, id: \.self) { msg in
                            HStack {
                                if msg.isUser {
                                    Spacer()
                                    Text(msg.text)
                                        .padding()
                                        .background(Color.white)
                                        .foregroundColor(.black)
                                        .cornerRadius(16)
                                } else {
                                    Text(msg.text)
                                        .padding()
                                        .background(Color.white.opacity(0.9))
                                        .foregroundColor(.black)
                                        .cornerRadius(16)
                                    Spacer()
                                }
                            }
                        }

                        if isTyping {
                            HStack {
                                Text("Nova is typing...")
                                    .italic()
                                    .foregroundColor(.white)
                                Spacer()
                            }
                        }
                    }
                    .padding()
                }

                // 📝 Input Field
                HStack {
                    TextField("Type a message...", text: $messageText)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(25)

                    Button(action: sendMessage) {
                        Image(systemName: "paperplane.fill")
                            .foregroundColor(.white)
                            .padding(12)
                            .background(Color.pink)
                            .clipShape(Circle())
                    }
                }
                .padding()
            }
            .navigationBarHidden(true)
        }
    }

    // 📤 Send + Get AI Response
    func sendMessage() {
        let userMessage = messageText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !userMessage.isEmpty else { return }

        messages.append(Message(text: userMessage, isUser: true))
        messageText = ""
        isTyping = true

        guard let url = URL(string: "http://14.139.187.229:8081/matern_ease/ai_chatbot1.php") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let body = "qns=\(userMessage.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
        request.httpBody = body.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                isTyping = false
            }

            guard let data = data, error == nil else {
                DispatchQueue.main.async {
                    messages.append(Message(text: "Nova: Sorry, something went wrong.", isUser: false))
                }
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let status = json["status"] as? Bool, status,
                   let dataArr = json["data"] as? [[String: Any]],
                   let answer = dataArr.first?["answer"] as? String {
                    DispatchQueue.main.async {
                        messages.append(Message(text: answer, isUser: false))
                    }
                } else {
                    DispatchQueue.main.async {
                        messages.append(Message(text: "Nova: Unable to understand that.", isUser: false))
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    messages.append(Message(text: "Nova: Error decoding response.", isUser: false))
                }
            }
        }.resume()
    }
}

#Preview {
    ChatBotView()
}

