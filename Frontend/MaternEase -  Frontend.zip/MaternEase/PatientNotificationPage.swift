import SwiftUI

struct PatientNotificationPage: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            VStack {
                // Top Navigation Bar
                HStack {
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.title)
                            .foregroundColor(.black)
                    }
                    Spacer()
                    Text("Notification")
                        .font(.system(size: 30, weight: .medium))
                        .foregroundColor(.black)
                    Spacer()
                }
                .padding()

                // Notification cards
                VStack(spacing: 25) {
                    // Navigate to QuizView on button tap
                    NotificationCard(text: "It's time to take your test", buttonText: "Take", destination: QuizView())
                    NotificationCardWithImage(text: "Sorry your streak is broken")
                }
                .padding()
                .frame(maxHeight: .infinity, alignment: .top)
            }
            .background(Color.white)
            .ignoresSafeArea(edges: .bottom)
            .navigationBarHidden(true)
        }
        .navigationBarHidden(true)
    }
}

// MARK: - Notification Card with NavigationLink
struct NotificationCard<Destination: View>: View {
    var text: String
    var buttonText: String
    var destination: Destination

    var body: some View {
        HStack {
            Text(text)
                .font(.system(size: 20, weight: .medium))
                .foregroundColor(.black)
                .padding()

            Spacer()

            NavigationLink(destination: destination) {
                Text(buttonText)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.black)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(20)
            }
            .padding()
        }
        .frame(maxWidth: .infinity, minHeight: 60)
        .background(Color(red: 1, green: 0.55, blue: 0.58))
        .cornerRadius(25)
    }
}

// MARK: - Notification Card with Image
struct NotificationCardWithImage: View {
    var text: String

    var body: some View {
        HStack {
            Image(systemName: "flame.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .padding()

            Text(text)
                .font(.system(size: 20, weight: .medium))
                .foregroundColor(.black)
                .padding()

            Spacer()
        }
        .frame(maxWidth: .infinity, minHeight: 80)
        .background(Color(red: 1, green: 0.55, blue: 0.58))
        .cornerRadius(25)
    }
}

// MARK: - Preview
struct PatientNotificationPage_Previews: PreviewProvider {
    static var previews: some View {
        PatientNotificationPage()
    }
}

