//
//  PatientListModel.swift
//  MaternEase
//
//  Created by SAIL on 25/04/25.
//


import Foundation


struct PatientListModel: Codable {
  
    let status, message: String
    let data: [PatientListData]
}


struct PatientListData: Codable {
    //var id: UUID? = UUID()
    let username, firstname, dp: String
}
