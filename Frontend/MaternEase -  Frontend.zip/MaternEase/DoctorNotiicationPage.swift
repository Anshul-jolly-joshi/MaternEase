import SwiftUI

struct DoctorNotificationPage: View {
    @Environment(\.dismiss) var dismiss // Used for popping back to the previous screen

    var body: some View {
//        NavigationView {
            VStack {
                // Top Navigation Bar (Fixed)
                HStack {
                    Button(action: {
                        dismiss() // Pops back with left-to-right transition
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.title)
                            .foregroundColor(.black)
                    }

                    Spacer()

                    Text("Notification")
                        .font(.system(size: 27, weight: .medium))
                        .foregroundColor(.black)

                    Spacer()
                }
                .padding()
                .background(Color.white) // Ensure header background remains visible
                .shadow(radius: 2) // Adds subtle shadow for distinction
                
                // Scrollable Content (if needed)
                ScrollView {
                    VStack {
                        // Single Notification Card
                        HStack {
                            Text("Patient score is low, so please\nconsult doctor")
                                .font(.system(size: 23, weight: .medium))
                                .foregroundColor(.black)
                                .padding(.horizontal)
                                .padding(.vertical, 10)
                            Spacer()
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color(red: 1, green: 0.55, blue: 0.58))
                        .cornerRadius(20)
                        .padding(.horizontal)
                    }
                    .padding(.top, 10)
                }
            }
            .background(Color.white)
            .ignoresSafeArea(edges: .bottom)
            .navigationBarHidden(true)
//        }
        .navigationBarHidden(true)
    }
}

struct DoctorNotificationPage_Previews: PreviewProvider {
    static var previews: some View {
        DoctorNotificationPage()
    }
}

