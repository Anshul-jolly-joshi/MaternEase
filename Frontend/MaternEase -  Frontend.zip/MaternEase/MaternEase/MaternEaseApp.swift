//
//  MaternEaseApp.swift
//  MaternEase
//
//  Created by SAIL on 18/03/25.
//

import SwiftUI

@main
struct MaternEaseApp: App {
    var body: some Scene {
        WindowGroup {
           // ContentView()
 
            if #available(iOS 16.0, *) {
                NavigationStack {
                    SplashScreen()
                }
            } else {
                SplashScreen()
                // Fallback on earlier versions
            }
           
        }
    }
}
