import SwiftUI

struct PatientLoginView: View {
    @State private var userID: String = ""
    @State private var password: String = ""
    @State private var isSecure: Bool = true
    @State private var navigateToDashboard = false
    @State private var navigateToLogin = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    @Environment(\.dismiss) var dismiss  // Used to pop the view

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color(red: 244/255, green: 226/255, blue: 226/255), Color(red: 210/255, green: 135/255, blue: 137/255)]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                Image("baby")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 130, height: 130)
                    .padding(.top, 30)

                VStack(alignment: .leading, spacing: 24) {
                    Text("Hello, Patient!")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                    Text("Sign in to access your dashboard")
                        .font(.subheadline)
                        .foregroundColor(.gray)

                    VStack(alignment: .leading, spacing: 6) {
                        Text("User ID")
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        TextField("Enter your Patient ID", text: $userID)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        Text("Password")
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        HStack {
                            if isSecure {
                                SecureField("Enter your password", text: $password)
                            } else {
                                TextField("Enter your password", text: $password)
                            }
                            Button(action: { isSecure.toggle() }) {
                                Image(systemName: isSecure ? "eye.slash" : "eye")
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                    }

                    Button(action: { loginUser() }) {
                        Text("Sign in")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color(red: 141/255, green: 64/255, blue: 66/255))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                    .alert(isPresented: $showAlert) {
                        Alert(title: Text("Login Failed"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                    }

                    NavigationLink(destination: PatientHomePage()
                        .navigationBarBackButtonHidden(true),
                        isActive: $navigateToDashboard) {
                        EmptyView()
                    }
                }
                .padding(25)
                .background(Color.white)
                .cornerRadius(30)
                .padding(.horizontal, 30)

                Spacer()

                // **Back Button (Pop to HomePageView)**
                Button(action: {
                    navigateToLogin = true
                    // Dismiss to navigate back to HomePageView
                     // This will pop the current view and go back to the HomePageView
                }) {
                    Circle()
                        .fill(Color.white)
                        .frame(width: 40, height: 40)
                        .shadow(color: .gray.opacity(0.3), radius: 3, x: 0, y: 2)
                        .overlay(
                            Image(systemName: "arrow.left")
                                .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        )
                }
                .padding(.bottom, 25)
                NavigationLink(destination: HomePageView()
                    .navigationBarBackButtonHidden(true),
                    isActive: $navigateToLogin) {
                    EmptyView()
                }
            }
            .navigationBarHidden(true)
        }
    }

   
    func loginUser() {
        APIService.login(username: userID, password: password) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    print(data)
                    if let userId = data.id {
                        UserDefaults.standard.set(userId, forKey: "sno")
                    }
                    navigateToDashboard = true
                case .failure(let error):
                    alertMessage = error.localizedDescription
                    showAlert = true
                }
            }
        }
    }
}


struct PatientLoginView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            PatientLoginView()
        }
    }
}
