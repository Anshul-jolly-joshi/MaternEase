import SwiftUI

struct SplashScreen: View {
    @State private var navigate = false

    var body: some View {
      
            ZStack {
                Color.white
                    .ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Spacer()

                    Image("women.png")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 350)
                        .shadow(radius: 20)

                    Text("MaternEase")
                        .font(.system(size: 40, weight: .heavy))
                        .foregroundColor(Color(red: 93/255, green: 42/255, blue: 43/255))
                        .shadow(radius: 5)

                    Spacer()
                }
                .padding()

               
                NavigationLink(destination: HomePageView().navigationBarBackButtonHidden(true), isActive: $navigate) {
                    EmptyView()
                }
                .hidden()
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    navigate = true
                }
            }
       // }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct SplashScreen_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreen()
    }
}

