import SwiftUI

struct DoctorMenu: View {
    @Environment(\.dismiss) var dismiss
    @State private var isLoggingOut = false // State to track logout navigation

    var body: some View {
//        NavigationView {
            ZStack {
                // Background Gradient
                LinearGradient(gradient: Gradient(colors: [Color(red: 0.84, green: 0.61, blue: 0.63),
                                                           Color(red: 0.95, green: 0.75, blue: 0.76)]),
                               startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                VStack {
                    // Top Navigation (Back Button)
                    HStack {
                        Button(action: {
                            dismiss() // Pops back with default left-to-right transition
                        }) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 27, weight: .medium))
                                .foregroundColor(.black)
                        }
                        .padding(.leading)

                        Spacer()
                    }
                    .frame(height: 50)

                    Spacer()

                    // Profile Section
                    HStack(alignment: .center, spacing: 30) {
                        // Profile Image
                        VStack {
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .frame(width: 100, height: 100)
                                .foregroundColor(.white)
                            
                            // Doctor Info under Profile Image
                            Text("Doctor")
                                .font(.custom("Poppins", size: 25).weight(.medium))
                                .foregroundColor(.black)
                                .padding(.top, 5)
                            
                            Text("@doctor123")
                                .font(.custom("Poppins", size: 18))
                                .foregroundColor(.black.opacity(0.8))
                        }

                        Spacer()

                        // Mother Image (Right)
                        Image("mother") // Replace with your actual image
                            .resizable()
                            .frame(width: 110, height: 110)
                            .clipShape(RoundedRectangle(cornerRadius: 20))
                            .shadow(radius: 5)
                    }
                    .padding(.horizontal, 40)
                    .padding(.top, 10)

                    Spacer()

                    // Buttons Section
                    VStack(spacing: 20) {
                        NavigationLink(destination: DoctorPassword()) {
                            Text("Change Password")
                                .font(.custom("Poppins", size: 18).weight(.medium))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity, minHeight: 50)
                                .background(LinearGradient(gradient: Gradient(colors: [Color(red: 0.7, green: 0.2, blue: 0.3),
                                                                                      Color(red: 0.9, green: 0.3, blue: 0.4)]),
                                                           startPoint: .topLeading, endPoint: .bottomTrailing))
                                .cornerRadius(15)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 15)
                                        .stroke(Color.white, lineWidth: 2)
                                )
                                .shadow(radius: 5)
                        }

                        // Logout Button
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.3)) {
                                isLoggingOut = true // Triggers transition
                            }
                        }) {
                            Text("Log Out")
                                .font(.custom("Poppins", size: 18).weight(.medium))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity, minHeight: 50)
                                .background(LinearGradient(gradient: Gradient(colors: [Color(red: 0.7, green: 0.2, blue: 0.3),
                                                                                      Color(red: 0.9, green: 0.3, blue: 0.4)]),
                                                           startPoint: .topLeading, endPoint: .bottomTrailing))
                                .cornerRadius(15)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 15)
                                        .stroke(Color.white, lineWidth: 2)
                                )
                                .shadow(radius: 5)
                        }
                    }
                    .padding(.horizontal, 60)
                    .padding(.bottom, 220)
                }

                // ✅ Right-to-left transition animation
                if isLoggingOut {
                    DoctorLoginView()
                        .transition(.move(edge: .trailing)) // Slide from right to left
                }
            }
            .navigationBarHidden(true)
//        }
        .navigationBarHidden(true)
    }
}

// Preview
struct DoctorMenu_Previews: PreviewProvider {
    static var previews: some View {
        DoctorMenu()
    }
}

