import SwiftUI
import AVKit

// MARK: - Video Model
struct Video: Identifiable, Decodable {
    let id: String
    let video_title: String
    let filepath: String

    enum CodingKeys: String, CodingKey {
        case id = "vid"
        case video_title
        case filepath
    }
}


struct PatientVideos: View {
    @Environment(\.dismiss) private var dismiss
    @State private var videos: [Video] = []
    @State private var errorMessage: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            // Header
            HStack {
                Button(action: {
                    dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.title)
                        .padding(.leading)
                        .foregroundColor(.black)
                }
                Spacer()
                Image("mother")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 90, height: 90)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
                    .offset(x: -30, y: 58)
            }

            Text("Videos")
                .font(.system(size: 30, weight: .medium))
                .bold()
                .padding(.leading)

            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.horizontal)
            }

            ScrollView {
                VStack(spacing: 20) {
                    // Loop through videos and pass data to VideoCard
                    ForEach(videos) { video in
                        VideoCards(title: video.video_title, filepath: video.filepath)
                    }
                }
                .padding(.horizontal)
            }

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.99, green: 1, blue: 1))
        .navigationBarHidden(true)
        .onAppear {
            fetchVideos()
        }
    }

    // MARK: - Fetch Videos
    func fetchVideos() {
        guard let url = URL(string: "http://14.139.187.229:8081/matern_ease/videolist.php") else {
            self.errorMessage = "Invalid URL"
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.errorMessage = "Error: \(error.localizedDescription)"
                }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    self.errorMessage = "No data received"
                }
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let status = json["status"] as? String,
                   let message = json["message"] as? String {
                    if status == "true", let dataArray = json["data"] as? [[String: Any]] {
                        let jsonData = try JSONSerialization.data(withJSONObject: dataArray)
                        let decodedVideos = try JSONDecoder().decode([Video].self, from: jsonData)
                        DispatchQueue.main.async {
                            self.videos = decodedVideos
                        }
                    } else {
                        DispatchQueue.main.async {
                            self.errorMessage = message
                        }
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.errorMessage = "Failed to parse response"
                }
            }
        }.resume()
    }
}

// MARK: - Video Card View
struct VideoCards: View {
    let title: String
    let filepath: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.headline)

            if let url = URL(string: "http://localhost/pregbackend/\(filepath)") {
                VideoPlayer(player: AVPlayer(url: url))
                    .frame(height: 200)
                    .cornerRadius(10)
                    .shadow(radius: 4)
            } else {
                Text("Invalid video URL")
                    .foregroundColor(.red)
            }
        }
        .padding()
        .background(Color.pink.opacity(0.2))
        .cornerRadius(12)
    }
}

// MARK: - Preview
struct PatientVideos_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            PatientVideos()
        }
    }
}

