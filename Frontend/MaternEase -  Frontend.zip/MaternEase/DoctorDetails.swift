import SwiftUI

struct DoctorDetails: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var name = ""
    @State private var contact = ""
    @State private var age = ""
    @State private var gender = ""
    @State private var specialist = ""
    @State private var isSubmitting = false
    @State private var responseMessage = ""
    @State private var shouldNavigate = false

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Register Your Details")
                    .font(.title)
                    .fontWeight(.bold)

                DoctorInputField(title: "Name", text: $name)
                DoctorInputField(title: "Contact", text: $contact)
                DoctorInputField(title: "Age", text: $age)

                VStack(alignment: .leading) {
                    Text("Gender")
                        .font(.headline)
                        .foregroundColor(.black)
                    TextField("Enter Gender", text: $gender)
                        .padding()
                        .background(Color.pink.opacity(0.3))
                        .cornerRadius(10)
                        .keyboardType(.default)
                }

                DoctorInputField(title: "Specialist", text: $specialist)

                Button(action: {
                    submitForm()
                }) {
                    Text("Submit")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(10)
                }
                .padding(.top, 10)

                if isSubmitting {
                    ProgressView("Submitting...")
                        .padding()
                }

                Text(responseMessage)
                    .foregroundColor(.red)
                    .padding()

                // Navigate to DoctorHomePage if submission is successful
                NavigationLink(destination: DoctorHomePage(), isActive: $shouldNavigate) {
                    EmptyView()
                }

                Spacer()
            }
            .padding()
            .navigationBarItems(leading:
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                }
            )
        }
        .navigationBarHidden(true)
    }

    func submitForm() {
        guard !name.isEmpty, !contact.isEmpty, !age.isEmpty, !gender.isEmpty, !specialist.isEmpty else {
            responseMessage = "Please fill in all fields."
            return
        }

        isSubmitting = true

        let parameters = [
            "name": name,
            "contact": contact,
            "age": age,
            "gender": gender,
            "specialist": specialist
        ]

        guard let url = URL(string: "http://14.139.187.229:8081/matern_ease/Doctordetails.php") else {
            responseMessage = "Invalid URL"
            isSubmitting = false
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        let bodyString = parameters.map { "\($0.key)=\($0.value)" }.joined(separator: "&")
        request.httpBody = bodyString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.isSubmitting = false
                if let error = error {
                    responseMessage = "Error: \(error.localizedDescription)"
                    return
                }

                if let data = data {
                    do {
                        let decodedResponse = try JSONDecoder().decode(APIResponse.self, from: data)
                        if decodedResponse.status == "true" {
                            responseMessage = "Data submitted successfully!"
                            shouldNavigate = true
                        } else {
                            responseMessage = decodedResponse.message
                        }
                    } catch {
                        responseMessage = "Failed to decode the response."
                    }
                }
            }
        }.resume()
    }
}

// Custom input field
struct DoctorInputField: View {
    var title: String
    @Binding var text: String

    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.headline)
                .foregroundColor(.black)
            TextField("Enter \(title)", text: $text)
                .padding()
                .background(Color.pink.opacity(0.3))
                .cornerRadius(10)
        }
    }
}

// Response model
struct APIResponse: Decodable {
    let status: String
    let message: String
    let data: [ResponseData]

    struct ResponseData: Decodable {
        let insertedId: Int
    }
}

// Preview (no DoctorHomePage here since it's already in your project)
struct DoctorDetails_Previews: PreviewProvider {
    static var previews: some View {
        DoctorDetails()
    }
}

