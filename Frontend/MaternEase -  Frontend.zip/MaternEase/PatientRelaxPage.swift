import SwiftUI

struct StressReliefView: View {
    @Environment(\.dismiss) private var dismiss // Dismiss for pop action
    
    var body: some View {
//        NavigationView {
            ZStack {
                // Gradient Background
                LinearGradient(gradient: Gradient(colors: [Color(red: 255/255, green: 230/255, blue: 230/255), Color(red: 255/255, green: 200/255, blue: 200/255)]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .ignoresSafeArea()

                VStack(spacing: 20) {
                    // Back Button (Slides from right to left)
                    HStack {
                        Button(action: {
                            dismiss() // Slide back to PatientHomePage
                        }) {
                            Image(systemName: "chevron.left")
                                .foregroundColor(.black)
                                .font(.title2)
                                .padding()
                        }
                        Spacer()
                    }
                    .padding(.horizontal)
                    .padding(.top, 10) // Adjust top padding

                    // Title
                    Text("Stress Relief")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.horizontal)
                        .padding(.bottom, 20) // Reduced bottom padding

                    // Centered Buttons with better spacing
                    VStack(spacing: 40) {
                        NavigationLink(destination: PatientMusic()) {
                            StressCardButton(title: "Soothing Music", systemImage: "music.quarternote.3")
                        }
                        NavigationLink(destination: PatientVideos()) {
                            StressCardButton(title: "Relaxing Video", systemImage: "film")
                        }
                        NavigationLink(destination: PatientMeditation()) {
                            StressCardButton(title: "Meditation", systemImage: "figure.mind.and.body")
                        }
                    }
                    .padding(.horizontal, 20)

                    Spacer()
                }
            }
            .navigationBarHidden(true)
//        }
        .navigationBarHidden(true)
    }
}

// Stress Card Button Component
struct StressCardButton: View {
    let title: String
    let systemImage: String

    var body: some View {
        HStack {
            Text(title)
                .font(.headline)
                .foregroundColor(.black)
            Spacer()
            Image(systemName: systemImage)
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
                .foregroundColor(.black)
        }
        .padding()
        .frame(height: 80)
        .frame(maxWidth: .infinity)
        .background(Color(red: 255/255, green: 153/255, blue: 153/255))
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 4)
    }
}

// ✅ **Preview**
struct StressReliefView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            StressReliefView()
        }
    }
}

