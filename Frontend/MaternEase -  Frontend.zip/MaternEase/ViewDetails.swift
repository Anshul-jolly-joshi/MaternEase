import SwiftUI

struct Patient: Codable {
    let sno: String
    let firstname: String
    let lastname: String
    let age: String
    let gender: String?
    let height: String?
    let weight: String?
    let blood_group: String?
    let contact: String?
}

struct PatientResponse: Codable {
    let status: String
    let data: [Patient]
}

struct ViewDetails: View {
    @Environment(\.dismiss) private var dismiss

    @State private var firstName = ""
    @State private var lastName = ""
    @State private var age = ""
    @State private var gender = ""
    @State private var height = ""
    @State private var weight = ""
    @State private var bloodGroup = ""
    @State private var contact = ""

    private var sno: String {
        UserDefaults.standard.string(forKey: "sno") ?? ""
    }

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.white.opacity(0.3), Color.blue.opacity(0.3)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .edgesIgnoringSafeArea(.all)

            VStack(spacing: 0) {
                HStack {
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.title)
                            .foregroundColor(.black)
                    }
                    Spacer()
                }
                .padding([.top, .leading])
                .background(Color.pink.opacity(0.3))

                Text("Patient Profile")
                    .font(.title2)
                    .bold()
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)
                    .padding()
                    .background(Color.pink.opacity(0.3))

                ScrollView {
                    VStack(alignment: .leading, spacing: 15) {
                        ReadOnlyField(title: "First Name", value: firstName)
                        ReadOnlyField(title: "Last Name", value: lastName)
                        ReadOnlyField(title: "Age", value: age)
                        ReadOnlyField(title: "Sex", value: gender)
                        ReadOnlyField(title: "Height", value: height)
                        ReadOnlyField(title: "Weight", value: weight)
                        ReadOnlyField(title: "Blood Group", value: bloodGroup)
                        ReadOnlyField(title: "Contact", value: contact)
                    }
                    .padding()
                }
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            fetchPatientDetails()
        }
    }

    private func fetchPatientDetails() {
        guard !sno.isEmpty else {
            print("SNO not found in UserDefaults")
            return
        }

        guard let url = URL(string: "http://14.139.187.229:8081/matern_ease/fetch_patients.php") else {
            print("Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let postString = "sno=\(sno)"
        request.httpBody = postString.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
                return
            }

            guard let data = data else {
                print("No data returned")
                return
            }

            do {
                let decodedResponse = try JSONDecoder().decode(PatientResponse.self, from: data)
                if decodedResponse.status == "true", let patient = decodedResponse.data.first {
                    DispatchQueue.main.async {
                        self.firstName = patient.firstname
                        self.lastName = patient.lastname
                        self.age = patient.age
                        self.gender = patient.gender ?? ""
                        self.height = patient.height ?? ""
                        self.weight = patient.weight ?? ""
                        self.bloodGroup = patient.blood_group ?? ""
                        self.contact = patient.contact ?? ""
                    }
                } else {
                    print("No patient found or invalid response")
                }
            } catch {
                print("Decoding error: \(error.localizedDescription)")
            }
        }.resume()
    }
}

struct ReadOnlyField: View {
    let title: String
    let value: String

    var body: some View {
        VStack(alignment: .leading) {
            Text(title).font(.headline)
            Text(value.isEmpty ? "Not Available" : value)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.pink.opacity(0.3))
                .cornerRadius(10)
        }
    }
}

struct ViewDetails_Previews: PreviewProvider {
    static var previews: some View {
        ViewDetails()
    }
}

