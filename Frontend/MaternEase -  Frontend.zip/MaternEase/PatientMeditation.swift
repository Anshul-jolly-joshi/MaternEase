import SwiftUI
import AVKit

// ✅ MeditationVideo Model
struct MeditationVideo: Identifiable, Codable {
    var id: String { vid }
    let vid: String
    let video_title: String
    let video_one: String
    
    var fullVideoURL: URL? {
        // Important: Change localhost to your system's IP address if running on real iPhone device
        return URL(string: "http://14.139.187.229:8081/matern_ease/" + video_one)
    }
}

// ✅ MeditationAPIResponse Model
struct MeditationAPIResponse: Codable {
    let status: Bool
    let message: String
    let data: [MeditationVideo]
}

// ✅ MeditationVideoViewModel for API Call
class MeditationVideoViewModel: ObservableObject {
    @Published var videos: [MeditationVideo] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var playingVideoID: String? // Track currently playing video

    func fetchMeditationVideos() {
        guard let url = URL(string: "http://14.139.187.229:8081/matern_ease/mlist.php") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        isLoading = true
        errorMessage = nil

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false

                if let error = error {
                    self.errorMessage = error.localizedDescription
                    return
                }

                guard let data = data else {
                    self.errorMessage = "No data received"
                    return
                }

                do {
                    let decodedResponse = try JSONDecoder().decode(MeditationAPIResponse.self, from: data)
                    if decodedResponse.status {
                        self.videos = decodedResponse.data
                    } else {
                        self.errorMessage = decodedResponse.message
                    }
                } catch {
                    self.errorMessage = "Failed to decode response"
                }
            }
        }.resume()
    }
}

// ✅ VideoCard Component
struct VideoCard: View {
    var video: MeditationVideo
    @Binding var playingVideoID: String?
    @State private var player: AVPlayer?

    var isPlaying: Bool {
        playingVideoID == video.id
    }

    var body: some View {
        VStack(alignment: .leading) {
            Text(video.video_title)
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(.black)

            if let url = video.fullVideoURL, isPlaying {
                VideoPlayer(player: player)
                    .frame(height: 200)
                    .cornerRadius(10)
                    .onAppear {
                        if player == nil {
                            player = AVPlayer(url: url)
                        }
                        player?.play()
                    }
                    .onDisappear {
                        player?.pause()
                    }
            }

            HStack {
                Spacer()

                // Play/Pause toggle
                Button(action: {
                    if isPlaying {
                        playingVideoID = nil
                        player?.pause()
                    } else {
                        playingVideoID = video.id
                        player?.play()
                    }
                }) {
                    Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                        .font(.system(size: 40))
                        .foregroundColor(.white)
                }

                Spacer()
            }
            .padding(.top, 10)
        }
        .padding()
        .background(Color(red: 1, green: 0.55, blue: 0.58))
        .cornerRadius(20)
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.black.opacity(0.3), lineWidth: 0.5)
        )
    }
}

// ✅ PatientMeditation View
struct PatientMeditation: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = MeditationVideoViewModel()

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Button(action: {
                    dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.title)
                        .padding(.leading)
                        .foregroundColor(.black)
                }
                Spacer()

                Image("mother")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 90, height: 90)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
                    .offset(x: -30, y: 58)
            }

            Text("Meditation")
                .font(.system(size: 30, weight: .medium))
                .bold()
                .padding(.leading)

            if viewModel.isLoading {
                Spacer()
                ProgressView()
                Spacer()
            } else if let errorMessage = viewModel.errorMessage {
                Spacer()
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
                Spacer()
            } else {
                ScrollView {
                    VStack(spacing: 20) {
                        ForEach(viewModel.videos) { video in
                            VideoCard(video: video, playingVideoID: $viewModel.playingVideoID)
                        }
                    }
                    .padding(.horizontal)
                }
            }

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.99, green: 1, blue: 1))
        .navigationBarHidden(true)
        .onAppear {
            viewModel.fetchMeditationVideos()
        }
    }
}

// ✅ Preview
struct PatientMeditation_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            PatientMeditation()
        }
    }
}

