import SwiftUI

struct TrackerView: View {
    @Environment(\.presentationMode) var presentationMode  // Access navigation stack

    var body: some View {
//        NavigationView {
            ZStack {
                // Background Gradient
                LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue.opacity(0.2)]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 20) {
                    Spacer().frame(height: 50) // Moves the title and back button down

                    // Back button and Title in HStack for alignment
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss() // Pops back to PatientDashboard
                        }) {
                            Image(systemName: "chevron.left")
                                .font(.title)
                                .foregroundColor(.black)
                        }
                        Text("Tracker")
                            .font(.title)
                            .fontWeight(.bold)
                            .padding(.leading, 10)

                        Spacer()
                    }
                    .padding(.horizontal)

                    Spacer() // Pushes buttons towards the center

                    // Mood Tracker Button - ✅ Navigates to MoodTrackerView
                    NavigationLink(destination: MoodTrackerView()
                        .transition(.move(edge: .trailing))) {
                        HStack {
                            Text("Mood Tracker")
                                .font(.headline)
                                .foregroundColor(.black)

                            Spacer()

                            Image(systemName: "face.smiling")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 100)
                        }
                        .padding()
                        .frame(maxWidth: .infinity, minHeight: 80)
                        .background(Color.pink.opacity(0.85))
                        .cornerRadius(15)
                    }
                    .padding(.horizontal)

                    // Space between buttons
                    Spacer().frame(height: 20)

                    // Sleep Tracker Button - ✅ Navigates to HomeView
                    NavigationLink(destination: HomeView()
                        .transition(.move(edge: .trailing))) {
                        HStack {
                            Text("Sleep Tracker")
                                .font(.headline)
                                .foregroundColor(.black)

                            Spacer()

                            Image(systemName: "bed.double.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 100)
                        }
                        .padding()
                        .frame(maxWidth: .infinity, minHeight: 80)
                        .background(Color.pink.opacity(0.85))
                        .cornerRadius(15)
                    }
                    .padding(.horizontal)

                    Spacer() // Keeps layout balanced
                }
            }
            .navigationBarHidden(true) // Hide default navigation bar
//        }
        .navigationBarHidden(true)
    }
}

struct TrackerView_Previews: PreviewProvider {
    static var previews: some View {
        TrackerView()
    }
}

