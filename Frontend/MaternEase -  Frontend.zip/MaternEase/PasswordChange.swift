import SwiftUI

struct PasswordChange: View {
    @Environment(\.dismiss) private var dismiss

    @State private var username: String = ""
    @State private var oldPassword: String = ""
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""

    @State private var errorMessage: String = ""
    @State private var successMessage: String = ""
    @State private var showSuccessMessage: Bool = false
    @State private var navigate = false

    var body: some View {
        if #available(iOS 16.0, *) {
            NavigationStack {
                ZStack {
                    Color.pink.opacity(0.5).edgesIgnoringSafeArea(.all)

                    VStack {
                        HStack {
                            Button(action: {
                                dismiss()
                            }) {
                                Image(systemName: "chevron.left")
                                    .foregroundColor(.black)
                                    .font(.title2)
                            }
                            Spacer()
                        }
                        .padding(.leading, 20)
                        .padding(.top, 10)

                        Spacer()

                        Image(systemName: "person.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 80)

                        Text("Edit Password")
                            .font(.title)
                            .bold()
                            .foregroundColor(.black)
                            .padding(.bottom, 20)

                        VStack(alignment: .leading, spacing: 15) {
                            Text("User ID")
                                .font(.headline)
                            TextField("Enter User ID", text: $username)
                                .textFieldStyle(RoundedBorderTextFieldStyle())

                            Text("Old Password")
                                .font(.headline)
                            SecureField("Enter Old Password", text: $oldPassword)
                                .textFieldStyle(RoundedBorderTextFieldStyle())

                            Text("New Password")
                                .font(.headline)
                            SecureField("Enter New Password", text: $newPassword)
                                .textFieldStyle(RoundedBorderTextFieldStyle())

                            Text("Confirm Password")
                                .font(.headline)
                            SecureField("Confirm New Password", text: $confirmPassword)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                        .padding(.horizontal, 20)

                        if !errorMessage.isEmpty {
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .font(.subheadline)
                                .padding(.top, 10)
                        }

                        if showSuccessMessage {
                            Text(successMessage)
                                .foregroundColor(.green)
                                .font(.subheadline)
                                .padding(.top, 10)
                        }

                        Spacer()

                        Button(action: {
                            if newPassword == confirmPassword && !newPassword.isEmpty {
                                changePassword()
                            } else {
                                errorMessage = "Passwords do not match or are empty"
                            }
                        }) {
                            Text("Change Password")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.brown)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .padding(.horizontal, 20)
                        }

                        NavigationLink(destination: PatientHomePage(), isActive: $navigate) {
                            EmptyView()
                        }

                        Spacer()
                    }
                    .padding()
                }
                .navigationBarHidden(true)
            }
        } else {
            // Handle older iOS if needed
            Text("Unsupported iOS version")
        }
    }

    func changePassword() {
        guard let url = URL(string: "http://14.139.187.229:8081/matern_ease/patientpasswordchange.php") else {
            self.errorMessage = "Invalid server URL"
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let body = "username=\(username)&old_password=\(oldPassword)&new_password=\(newPassword)"
        request.httpBody = body.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.errorMessage = "Error: \(error.localizedDescription)"
                }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    self.errorMessage = "No data received"
                }
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let status = json["status"] as? String,
                   let message = json["message"] as? String {
                    DispatchQueue.main.async {
                        if status == "true" {
                            self.successMessage = message
                            self.errorMessage = ""
                            self.showSuccessMessage = true

                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                self.navigate = true
                            }
                        } else {
                            self.errorMessage = message
                        }
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.errorMessage = "Failed to decode response"
                }
            }
        }.resume()
    }
}

#Preview {
    PasswordChange()
}

