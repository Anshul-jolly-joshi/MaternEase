import SwiftUI

struct HomePageView: View {
    var body: some View {
            VStack {
                Spacer()
                
                // Pregnant Woman Illustration
                Image("women.png") // Ensure this image is added to Assets.xcassets
                    .resizable()
                    .scaledToFit()
                    .frame(width: 370.0, height: 450.0)
                
                Spacer()
                
                // Three separate buttons for Patient, Guardian, Doctor
                VStack(spacing: 16) {
                    
                    // Patient Button
                    NavigationLink(destination: PatientLoginView()) {
                        Text("Patient")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(red: 0.6, green: 0, blue: 0), lineWidth: 2)
                            )
                            .foregroundColor(Color(red: 0.6, green: 0, blue: 0))
                    }
                    
                    // Guardian Button
                    NavigationLink(destination: GuardianLoginView()) {
                        Text("Guardian")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(red: 0.6, green: 0, blue: 0), lineWidth: 2)
                            )
                            .foregroundColor(Color(red: 0.6, green: 0, blue: 0))
                    }
                    
                    // Doctor Button
                    NavigationLink(destination: DoctorLoginView()) {
                        Text("Doctor")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(red: 0.6, green: 0, blue: 0), lineWidth: 2)
                            )
                            .foregroundColor(Color(red: 0.6, green: 0, blue: 0))
                    }
                    
                }
                .padding(.bottom, 50)
                .padding(.horizontal)
            }
            .padding()
            .navigationTitle("Select User Type")
//        }
        .navigationBarHidden(true)
    }
}


struct HomePageView_Previews: PreviewProvider {
    static var previews: some View {
        HomePageView()
    }
}
