import SwiftUI

struct PatientDetailsView: View {
    @Environment(\.presentationMode) var presentationMode

    @State private var firstName = ""
    @State private var lastName = ""
    @State private var age = ""
    @State private var gender = ""
    @State private var height = ""
    @State private var weight = ""
    @State private var bloodGroup = ""
    @State private var contact = ""

    // Set this to the patient ID you want to fetch
    private var sno: String {
        UserDefaults.standard.string(forKey: "sno") ?? ""
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                VStack {
                    Text("Profile of Patient")
                        .font(.title2)
                        .bold()
                        .frame(maxWidth: .infinity)
                        .multilineTextAlignment(.center)
                        .padding()
                        .background(Color.pink.opacity(0.3))
                }
                .shadow(radius: 2)

                ZStack {
                    LinearGradient(
                        gradient: Gradient(colors: [Color.white.opacity(0.3), Color.blue.opacity(0.3)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .edgesIgnoringSafeArea(.all)

                    ScrollView {
                        VStack(alignment: .leading, spacing: 15) {
                            ReadOnlyTextField(title: "First Name", text: firstName)
                            ReadOnlyTextField(title: "Last Name", text: lastName)
                            ReadOnlyTextField(title: "Age", text: age)

                            VStack(alignment: .leading) {
                                Text("Sex").font(.headline)
                                Text(gender)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding()
                                    .background(Color.pink.opacity(0.3))
                                    .cornerRadius(10)
                                    .foregroundColor(.black)
                            }

                            ReadOnlyTextField(title: "Height", text: height)
                            ReadOnlyTextField(title: "Weight", text: weight)
                            ReadOnlyTextField(title: "Blood Group", text: bloodGroup)
                            ReadOnlyTextField(title: "Contact", text: contact)
                        }
                        .padding()
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                    }
                }
            }
            .onAppear {
                fetchPatientDetails()
            }
        }
        .navigationBarHidden(true)
    }

    // MARK: - Fetch Patient Data
    func fetchPatientDetails() {
        guard let url = URL(string: "http://14.139.187.229:8081/matern_ease/fetch_patients.php") else {
            print("Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let postData = "sno=\(sno)"
        request.httpBody = postData.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print("Request error: \(error?.localizedDescription ?? "Unknown")")
                return
            }

            do {
                let decoded = try JSONDecoder().decode(PatientDetailResponse.self, from: data)
                if decoded.status == "true", let detail = decoded.data.first {
                    DispatchQueue.main.async {
                        self.firstName = detail.firstname
                        self.lastName = detail.lastname
                        self.age = detail.age
                        self.gender = detail.gender
                        self.height = detail.height
                        self.weight = detail.weight
                        self.bloodGroup = detail.blood_group
                        self.contact = detail.contact
                    }
                } else {
                    print("No patient found: \(decoded.message)")
                }
            } catch {
                print("JSON decode error: \(error)")
            }
        }.resume()
    }
}

// MARK: - Read-Only TextField
struct ReadOnlyTextField: View {
    let title: String
    let text: String

    var body: some View {
        VStack(alignment: .leading) {
            Text(title).font(.headline)
            Text(text)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.pink.opacity(0.3))
                .cornerRadius(10)
                .foregroundColor(.black)
        }
    }
}

// MARK: - New Model Names
struct PatientDetailResponse: Codable {
    let status: String
    let message: String
    let data: [PatientDetail]
}

struct PatientDetail: Codable {
    let sno: String
    let firstname: String
    let lastname: String
    let age: String
    let gender: String
    let height: String
    let weight: String
    let blood_group: String
    let contact: String
}

// MARK: - Preview
struct PatientDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        PatientDetailsView()
    }
}

