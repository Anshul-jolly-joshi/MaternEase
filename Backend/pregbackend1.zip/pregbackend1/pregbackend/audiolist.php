<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    require("conn.php");

        // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // Establish the database connection
    // $servername = "localhost";
    // $username_db = "root";
    // $password_db = "";
    // $dbname = "pregnentdb";

    // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    // if ($conn->connect_error) {
    //     die("Connection failed: " . $conn->connect_error);
    // }

    // Query to fetch all patient details
    $sql = "SELECT id, filename ,filepath FROM audios";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the data
        $videoList = array();

        while ($row = $result->fetch_assoc()) {
            $videoList[] = $row;
        }

        // Convert the array to a JSON string
        $response = json_encode($videoList);
        echo $response;
    } else {
        // No patients found
        $response['status'] = 'failure';
        $response['message'] = 'No patients found';
        echo json_encode($response);
    }

    // Close the database connection
    $conn->close();
}
