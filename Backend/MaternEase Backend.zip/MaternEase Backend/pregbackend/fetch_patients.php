<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set response headers
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

// Database connection
$conn = new mysqli("localhost", "root", "", "pregnentdb");

if ($conn->connect_error) {
    echo json_encode([
        "status" => "false",
        "message" => "Database connection failed: " . $conn->connect_error,
        "data" => []
    ]);
    exit();
}

// Check if the request is POST and 'sno' is present in form data
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["sno"])) {
    $sno = $conn->real_escape_string($_POST["sno"]);

    // Updated SQL query with new columns
    $sql = "SELECT sno, firstname, lastname, age, gender, height, weight, blood_group ,contact FROM addpatient WHERE sno = '$sno'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $patient = $result->fetch_assoc();
        $patient['gender'] = 'Female'; // Add gender manually if not stored

        echo json_encode([
            "status" => "true",
            "message" => "Patient found",
            "data" => [$patient]
        ]);
    } else {
        echo json_encode([
            "status" => "false",
            "message" => "Patient not found",
            "data" => []
        ]);
    }
} else {
    echo json_encode([
        "status" => "false",
        "message" => "Invalid request. 'sno' not found in form-data.",
        "data" => []
    ]);
}

$conn->close();
?>

