<?php

require("conn.php");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['id'])) {
    $videoId = $_POST['id'];

    $sql = "SELECT video_one FROM pregvideo WHERE vid = $videoId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $videoFilePath = $row['video_one'];
        
        echo $videoFilePath;  // Return video URL instead of file content

    } else {
        echo "Video not found.";
    }
} else {
    echo "Video ID not provided.";
}

$conn->close();
?>
