<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"])) {
        $username = $_POST["username"];

        require("conn.php");

        if ($conn->connect_error) {
            $response = [
                'status' => false,
                'message' => 'Connection failed: ' . $conn->connect_error,
                'data' => []
            ];
            echo json_encode($response);
            exit();
        }

        $sql = "SELECT dp FROM addpatient WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $profileImage = $row['dp'];

            $imageUrl = !empty($profileImage) ? $profileImage : "http://your-server.com/default-profile.jpg";

            $response = [
                'status' => true,
                'message' => 'Profile image fetched successfully',
                'data' => [
                    [
                        'profile_image_url' => $imageUrl
                    ]
                ]
            ];
        } else {
            $response = [
                'status' => false,
                'message' => 'User not found',
                'data' => []
            ];
        }

        header('Content-Type: application/json');
        echo json_encode($response);
        $conn->close();
    } else {
        $response = [
            'status' => false,
            'message' => 'Username not provided',
            'data' => []
        ];
        header('Content-Type: application/json');
        echo json_encode($response);
    }
}
?>

