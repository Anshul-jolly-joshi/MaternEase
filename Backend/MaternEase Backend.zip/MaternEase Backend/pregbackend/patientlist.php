<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish the database connection
    require("conn.php");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to fetch all patient details
    $sql = "SELECT username, firstname, dp FROM addpatient";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        // Fetch the data
        $patientList = array();

        while ($row = $result->fetch_assoc()) {
            $profileImage = $row['dp'];

            if (!empty($profileImage) && file_exists($profileImage)) {
                $base64Image = base64_encode(file_get_contents($profileImage));
                $row['dp'] = $base64Image;
            } else {
                $row['dp'] = '';
            }
            $patientList[] = $row;
        }

        $response = [
            "status" => "true",
            "message" => "Patients fetched successfully",
            "data" => $patientList
        ];
    } else {
        // No patients found
        $response = [
            "status" => "false",
            "message" => "No patients found",
            "data" => []
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($response);

    // Close the database connection
    $conn->close();
}
?>

