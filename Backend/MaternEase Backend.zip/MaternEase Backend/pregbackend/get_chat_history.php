<?php
header("Content-Type: application/json");

// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pregnentdb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "failure", "message" => "Database connection failed"]));
}

// Get Chat History
$sql = "SELECT user_question, ai_response, created_at FROM chat_history ORDER BY created_at DESC LIMIT 10";
$result = $conn->query($sql);

$chatHistory = [];
while ($row = $result->fetch_assoc()) {
    $chatHistory[] = $row;
}

// Return JSON
echo json_encode(["status" => "success", "history" => $chatHistory]);

$conn->close();
?>
