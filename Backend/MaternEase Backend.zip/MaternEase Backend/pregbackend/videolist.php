<?php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish the database connection
    require("conn.php");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to fetch all video details including filepath
    $sql = "SELECT vid, video_title, video_one FROM pregvideo";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the data
        $videoList = array();

        while ($row = $result->fetch_assoc()) {
            $videoList[] = [
                "vid" => $row["vid"],
                "video_title" => $row["video_title"],
                "filepath" => $row["video_one"] // Include filepath in response
            ];
        }

        // Success response
        $response = [
            "status" => "true",
            "message" => "Data fetched successfully",
            "data" => $videoList
        ];
    } else {
        // No records found
        $response = [
            "status" => "false",
            "message" => "No data found",
            "data" => []
        ];
    }

    echo json_encode($response);
    $conn->close();
}
?>

