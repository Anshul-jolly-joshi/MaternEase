<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"]) && isset($_POST["poh"])){ // Check for the presence of "username" in $data
        $poh = $_POST["poh"];
        $oc = $_POST["oc"];
        $ga = $_POST["ga"];
        $poad = $_POST["poad"];
        $doad = $_POST["doad"];
        $dd=$_POST["dd"];
        $com=$_POST["com"];
        $bd=$_POST["bd"];
        $bw=$_POST["bw"];
        $username =  $_POST["username"];

        // Establish the database connection
        $servername = "localhost";
        $username_db = "root";
        $password_db = "";
        $dbname = "pregnentdb";

        $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to insert data into the database
        $sql = "UPDATE addpatient SET  f_past_obstetric_history= '$poh', f_outcome  = '$oc' , f_gestational_age = '$ga' , f_place_of_a_d = '$poad', f_detail_of_a_d='$doad', f_delivery_details='$dd', f_complication='$com', f_baby_details='$bd', f_baby_weight='$bw'   WHERE username = '$username'";

        if (mysqli_query($conn, $sql)) {
            $response['status'] = 'success';
            $response['message'] = 'Data inserted successfully';
        } else {
            $response['status'] = 'failure';
            $response['error'] = $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Username not provided';
    }

    echo json_encode($response);
}
?>
