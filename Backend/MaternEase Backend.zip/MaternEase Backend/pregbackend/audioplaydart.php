<?php
// Database connection details
require("conn.php");

        // Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get video ID from the POST data
$id = $_POST['id'];

// Fetch video path from the database based on the username
$sql = "SELECT filepath FROM audios WHERE id = '$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $videoPath = $row['filepath'];
    // Return the video path as JSON
    echo  $videoPath;
} else {
    echo  'Video not found for the given username';
}

$conn->close();
?>