<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Only handle POST requests
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Check for required field (password as example)
    if (isset($_POST["password"])) {
        // Extract form data from $_POST
        $password = $_POST["password"];
        $firstname = $_POST["firstname"];
        $lastname = $_POST["lastname"];
        $contact = $_POST["contact"];
        $age = $_POST["age"];
        $dowo = $_POST["dowo"];
        $address = $_POST["address"];
        $informant = $_POST["informant"];
        $informant_related = $_POST["informant_related"];
        $educational_history = $_POST["educational_history"];
        $occupational_history = $_POST["occupational_history"];
        $religion = $_POST["religion"];
        $date_of_first_visit_to_smch = $_POST["date_of_first_visit_to_smch"];
        $date_of_delivery = $_POST["date_of_delivery"];
        $granida = $_POST["granida"];
        $para = $_POST["para"];
        $live_children = $_POST["live_children"];
        $abortion = $_POST["abortion"];
        $ectogic = $_POST["ectogic"];
        $lmp = $_POST["lmp"];
        $cedd = $_POST["cedd"];
        $risk_factor = $_POST["risk_factor"];
        $stressors = $_POST["stressors"];
        $relevant_psychiatric_family_history = $_POST["relevant_psychiatric_family_history"];
        $detail_of_family_history = $_POST["detail_of_family_history"];
        $antenatal_visits = $_POST["antenatal_visits"];
        $conception = $_POST["conception"];
        $present_obstetric_history = $_POST["present_obstetric_history"];
        $s_past_obstetric_history = $_POST["s_past_obstetric_history"];
        $s_outcome = $_POST["s_outcome"];
        $s_detail_of_abortion = $_POST["s_detail_of_abortion"];
        $s_detail_of_ad = $_POST["s_detail_of_ad"];
        $s_delivery_details = $_POST["s_delivery_details"];
        $s_complication = $_POST["s_complication"];
        $s_baby_details = $_POST["s_baby_details"];
        $t_past_obstetric_history = $_POST["t_past_obstetric_history"];
        $t_outcome = $_POST["t_outcome"];
        $t_detail_of_abortion = $_POST["t_detail_of_abortion"];
        $t_detail_of_ad = $_POST["t_detail_of_ad"];
        $t_delivery_details = $_POST["t_delivery_details"];
        $t_complication = $_POST["t_complication"];
        $t_baby_details = $_POST["t_baby_details"];
        $dp = $_POST["dp"];
        $post_natal_period = $_POST["post_natal_period"];
        $past_medical_history = $_POST["past_medical_history"];
        $details_of_past_surgeries = $_POST["details_of_past_surgeries"];
        $personal_history = $_POST["personal_history"];
        $sleep_pattern = $_POST["sleep_pattern"];
        $history_of_hospital_adm = $_POST["history_of_hospital_adm"];
        $diagnosis = $_POST["diagnosis"];
        $sdate = date("Y-m-d");

        // DB connection
        require("conn.php");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Auto-generate username
        $result = $conn->query("SELECT COUNT(*) AS count FROM addpatient");
        $row = $result->fetch_assoc();
        $count = $row['count'] + 1;
        $username = "SMCU" . str_pad($count, 3, '0', STR_PAD_LEFT);

        // Calculate EDD from LMP
        $lmp_date = new DateTime($lmp);
        $edd_date = $lmp_date->add(new DateInterval('P280D'));
        $edd = $edd_date->format('Y-m-d');

        // SQL Insert
        $sql = "INSERT INTO addpatient (
            sno, firstname, lastname, age, daughterofwifeof, address, username, password, contact, informant, 
            informant_related, educational_history, occupation_history, religion, date_of_first_visit_to_smch, 
            date_of_delivery, granida, para, live_children, abortion, ectogic, lmp, edd, cedd, risk_factor, 
            stressors, relevant_psychiatric_family_history, Details_of_family_history, antenatal_visits, conception, 
            present_obstetric_history, s_past_obstetric_history, s_outcome, s_detail_of_abortion, s_detail_of_a_d, 
            s_delivery_details, s_complication, s_baby_details, t_past_obstetric_history, t_outcome, t_detail_of_abortion, 
            t_detail_of_a_d, t_delivery_details, t_complication, t_baby_details, dp, post_natal_period, past_medical_history, 
            details_of_past_surgeries, personal_history, sleep_pattern, history_of_hospital_adm, diagnosis
        ) VALUES (
            NULL, '$firstname', '$lastname', '$age', '$dowo', '$address', '$username', '$password', '$contact', '$informant', 
            '$informant_related', '$educational_history', '$occupational_history', '$religion', '$date_of_first_visit_to_smch', 
            '$date_of_delivery', '$granida', '$para', '$live_children', '$abortion', '$ectogic', '$lmp', '$edd', '$cedd', 
            '$risk_factor', '$stressors', '$relevant_psychiatric_family_history', '$detail_of_family_history', 
            '$antenatal_visits', '$conception', '$present_obstetric_history', '$s_past_obstetric_history', '$s_outcome', 
            '$s_detail_of_abortion', '$s_detail_of_ad', '$s_delivery_details', '$s_complication', '$s_baby_details', 
            '$t_past_obstetric_history', '$t_outcome', '$t_detail_of_abortion', '$t_detail_of_ad', '$t_delivery_details', 
            '$t_complication', '$t_baby_details', '$dp', '$post_natal_period', '$past_medical_history', '$details_of_past_surgeries', 
            '$personal_history', '$sleep_pattern', '$history_of_hospital_adm', '$diagnosis'
        )";

        if ($conn->query($sql) === TRUE) {
            $sql_mood = "INSERT INTO mood (username, date_insert) VALUES ('$username', '$sdate')";
            if ($conn->query($sql_mood) === TRUE) {
                $response = [
                    "status" => "true",
                    "data" => [[
                        "username" => $username,
                        "message" => "Patient and mood data inserted successfully"
                    ]]
                ];
            } else {
                $response = [
                    "status" => "false",
                    "data" => [[
                        "error" => "Mood insertion failed",
                        "details" => $conn->error
                    ]]
                ];
            }
        } else {
            $response = [
                "status" => "false",
                "data" => [[
                    "error" => "Main patient data insertion failed",
                    "details" => $conn->error
                ]]
            ];
        }

        $conn->close();
    } else {
        $response = [
            "status" => "false",
            "data" => [[ "error" => "Missing required parameters (password)" ]]
        ];
    }

    echo json_encode($response);
}
?>

