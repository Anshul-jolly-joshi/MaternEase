<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"]) && isset($_POST["mdate"])) {
        $username = $_POST["username"];
        $mdate = $_POST["mdate"];
        $sleephr = $_POST["pick"];
        $rating = $_POST["rate"];

        // Establish the database connection
        require("conn.php");

        if ($conn->connect_error) {
            die(json_encode([
                'status' => 'false',
                'message' => 'Database connection failed',
                'data' => []
            ]));
        }

        // Check if the combination of username and date exists
        $checkIfExistsSql = "SELECT * FROM mood WHERE username = '$username' AND date_insert = '$mdate'";
        $result = $conn->query($checkIfExistsSql);

        if ($result && $result->num_rows > 0) {
            // Update the existing record
            $updateSql = "UPDATE mood SET sleep_hours = '$sleephr', sleep_rateing = '$rating' WHERE username = '$username' AND date_insert = '$mdate'";
            if ($conn->query($updateSql) === TRUE) {
                $response = [
                    'status' => 'true',
                    'message' => 'Data updated successfully',
                    'data' => [
                        'username' => $username,
                        'date_insert' => $mdate,
                        'sleep_hours' => $sleephr,
                        'sleep_rateing' => $rating
                    ]
                ];
            } else {
                $response = [
                    'status' => 'false',
                    'message' => 'Failed to update data',
                    'data' => []
                ];
            }
        } else {
            // Insert a new record
            $insertSql = "INSERT INTO mood (username, date_insert, sleep_hours, sleep_rateing) VALUES ('$username', '$mdate', '$sleephr', '$rating')";
            if ($conn->query($insertSql) === TRUE) {
                $response = [
                    'status' => 'true',
                    'message' => 'Data inserted successfully',
                    'data' => [
                        'username' => $username,
                        'date_insert' => $mdate,
                        'sleep_hours' => $sleephr,
                        'sleep_rateing' => $rating
                    ]
                ];
            } else {
                $response = [
                    'status' => 'false',
                    'message' => 'Failed to insert data',
                    'data' => []
                ];
            }
        }

        $conn->close();
    } else {
        $response = [
            'status' => 'false',
            'message' => 'Username or date not provided',
            'data' => []
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($response);
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}
?>

