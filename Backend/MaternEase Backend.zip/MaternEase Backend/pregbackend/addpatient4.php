<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"]) && isset($_POST["poh"])){ // Check for the presence of "username" in $data
        $poh = $_POST["poh"];
        $oc = $_POST["oc"];
        $ga = $_POST["ga"];
        $poad = $_POST["poad"];
        $doad = $_POST["doad"];
        $dd=$_POST["dd"];
        $com=$_POST["com"];
        $bd=$_POST["bd"];
        $bw=$_POST["bw"];
        $username =  $_POST["username"];

        // Establish the database connection
        $servername = "localhost";
        $username_db = "root";
        $password_db = "";
        $dbname = "pregnentdb";

        $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to insert data into the database
        $sql = "UPDATE addpatient SET  s_past_obstetric_history= '$poh', s_outcome  = '$oc' , s_gestational_age = '$ga' , s_place_of_a_d = '$poad', s_detail_of_a_d='$doad', s_delivery_details='$dd', s_complication='$com', s_baby_details='$bd', s_baby_weight='$bw'   WHERE username = '$username'";

        if (mysqli_query($conn, $sql)) {
            $response['status'] = 'success';
            $response['message'] = 'Data inserted successfully';
        } else {
            $response['status'] = 'failure';
            $response['error'] = $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Username not provided';
    }

    echo json_encode($response);
}
?>
