<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON if needed (but you're using $_POST so json_decode might not be necessary)
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["userId"])) {
        $userId = $_POST["userId"];

        require("conn.php");

        if ($conn->connect_error) {
            $response = [
                'status' => false,
                'message' => 'Connection failed: ' . $conn->connect_error,
                'data' => []
            ];
            echo json_encode($response);
            exit();
        }

        $sql = "SELECT firstname, lastname, age, address, username, password, contact FROM addpatient WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $userData = [
                'username' => $row['username'],
                'password' => $row['password'],
                'firstname' => $row['firstname'],
                'lastname' => $row['lastname'],
                'age' => $row['age'],
                'address' => $row['address'],
                'contact' => $row['contact']
            ];

            $response = [
                'status' => true,
                'message' => 'User data fetched successfully',
                'data' => [$userData]
            ];
        } else {
            $response = [
                'status' => false,
                'message' => 'User not found',
                'data' => []
            ];
        }

        header('Content-Type: application/json');
        echo json_encode($response);
        $conn->close();
    } else {
        $response = [
            'status' => false,
            'message' => 'User ID not provided',
            'data' => []
        ];
        header('Content-Type: application/json');
        echo json_encode($response);
    }
}

?>

