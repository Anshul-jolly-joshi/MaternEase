<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];

        // Establish the database connection
        require("conn.php");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to check login credentials
        $sql = "SELECT * FROM addpatient WHERE username = '$username' AND password = '$password'";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            // Login successful
            $row = $result->fetch_assoc();
            $response = [
                "status" => "true",
                "message" => "Login successful",
                "data" => [
                    [
                        "username" => $row['username'],
                        "email" => $row['email'] ?? "",
                        "mobile" => $row['contact'] ?? "",
                        "id" => $row['sno'] ?? ""
                    ]
                ]
            ];
        } else {
            // Login failed
            $response = [
                "status" => "false",
                "message" => "Invalid username or password",
                "data" => []
            ];
        }

        $conn->close();
    } else {
        $response = [
            "status" => "false",
            "message" => "Username or password not provided",
            "data" => []
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($response);
}
?>

