<?php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    header('Content-Type: application/json');

    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];

        require("conn.php");

        // Check connection
        if ($conn->connect_error) {
            echo json_encode([
                'status' => "false",
                'message' => "DB Connection failed: " . $con->connect_error,
                'data' => []
            ]);
            exit;
        }

        // Avoid SQL injection (Prepared Statements Recommended)
        $stmt = $conn->prepare("SELECT s_no FROM dlogin WHERE username = ? AND password = ?");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $response = [
                'status' => "true",
                'message' => "Login successful",
                'data' => [
                    [
                        "userId" => $row['s_no'] // Here s_no as userId
                    ]
                ]
            ];
        } else {
            $response = [
                'status' => "false",
                'message' => "Login failure",
                'data' => []
            ];
        }

        $stmt->close();
        $conn->close();
    } else {
        $response = [
            'status' => "false",
            'message' => "Username or password not provided",
            'data' => []
        ];
    }

    echo json_encode($response);
}
?>
