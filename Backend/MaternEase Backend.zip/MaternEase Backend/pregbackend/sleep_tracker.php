<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pregnentdb"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(["status" => "false", "message" => "Database connection failed"]);
    exit();
}

// 🔹 **INSERT Sleep Data (POST)**
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['sno']) && isset($_POST['sleep_date']) && isset($_POST['sleep_duration'])) {
    $sno = $_POST['sno'];
    $sleep_date = $_POST['sleep_date'];
    $sleep_duration = $_POST['sleep_duration'];

    $stmt = $conn->prepare("INSERT INTO sleep_data (sno, sleep_date, sleep_duration) VALUES (?, ?, ?)");
    $stmt->bind_param("isd", $sno, $sleep_date, $sleep_duration);

    if ($stmt->execute()) {
        echo json_encode([
            "status" => "true",
            "message" => "Sleep data inserted successfully",
            "data" => [
                "sno" => $sno,
                "sleep_date" => $sleep_date,
                "sleep_duration" => $sleep_duration
            ]
        ]);
    } else {
        echo json_encode(["status" => "false", "message" => "Failed to insert sleep data"]);
    }
    $stmt->close();
    exit();
}

// 🔹 **FETCH Sleep Data (POST Instead of GET)**
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['sno']) && !isset($_POST['sleep_date'])) {
    $sno = $_POST['sno'];

    $stmt = $conn->prepare("SELECT id, sno, sleep_date, sleep_duration FROM sleep_data WHERE sno = ?");
    $stmt->bind_param("i", $sno);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                "id" => $row["id"],
                "sno" => $row["sno"],
                "sleep_date" => $row["sleep_date"],
                "sleep_duration" => $row["sleep_duration"]
            ];
        }
        echo json_encode(["status" => "true", "message" => "Data fetched successfully", "data" => $data]);
    } else {
        echo json_encode(["status" => "false", "message" => "No data found", "data" => []]);
    }
    $stmt->close();
    exit();
}

$conn->close();
?>
