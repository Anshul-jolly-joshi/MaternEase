<?php
require("conn.php");

// Set response to JSON
header('Content-Type: application/json');

// Check connection
if ($conn->connect_error) {
    die(json_encode(['status' => 'false', 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Validate input
if (!isset($_POST['vid']) || empty($_POST['vid'])) {
    echo json_encode(['status' => 'false', 'message' => 'Missing video ID']);
    exit;
}

$vid = $_POST['vid'];

// Secure query using prepared statements
$sql = "SELECT video_one FROM pregvideo WHERE vid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $vid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode([
        'status' => 'true',
        'video_path' => $row['video_one']
    ]);
} else {
    echo json_encode(['status' => 'false', 'message' => 'Video not found for the given ID']);
}

$stmt->close();
$conn->close();
?>

