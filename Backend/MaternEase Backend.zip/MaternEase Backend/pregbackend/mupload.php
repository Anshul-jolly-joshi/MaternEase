<?php
require("conn.php");

// Check connection
if ($conn->connect_error) {
    die(json_encode(["status" => "false", "message" => "Database connection failed: " . $conn->connect_error]));
}

// Set upload directory (Windows-safe)
$uploadDir = __DIR__ . '/videos/';

// Ensure the directory exists and is writable
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if (!is_writable($uploadDir)) {
    die(json_encode(["status" => "false", "message" => "Upload directory is not writable."]));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['uploaded_file'])) {
    
    $file = $_FILES['uploaded_file'];
    $filename = isset($_POST['video_title']) ? $_POST['video_title'] : '';

    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        die(json_encode(["status" => "false", "message" => "File upload error code: " . $file['error']]));
    }

    // Get file extension
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $safeFilename = uniqid('video_', true) . "." . $ext; // Unique filename

    $uploadPath = $uploadDir . $safeFilename;

    // Ensure it's an actual upload file
    if (is_uploaded_file($file['tmp_name'])) {
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            // Prepare relative path for DB (avoid absolute paths in DB)
            $relativePath = "videos/" . $safeFilename;

            // Insert into DB
            $sql = "INSERT INTO meditation (video_title, video_one) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);

            if (!$stmt) {
                die(json_encode(["status" => "false", "message" => "SQL prepare failed: " . $conn->error]));
            }

            $stmt->bind_param("ss", $filename, $relativePath);

            if ($stmt->execute()) {
                echo json_encode(["status" => "true", "message" => "Video uploaded and saved to DB successfully"]);
            } else {
                echo json_encode(["status" => "false", "message" => "DB insert failed: " . $stmt->error]);
            }

            $stmt->close();
        } else {
            echo json_encode(["status" => "false", "message" => "move_uploaded_file failed"]);
        }
    } else {
        echo json_encode(["status" => "false", "message" => "Temporary file not found"]);
    }

} else {
    echo json_encode(["status" => "false", "message" => "Invalid request, file missing"]);
}

$conn->close();
?>

