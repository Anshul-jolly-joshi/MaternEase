<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish the database connection
    require("conn.php");

        // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // $servername = "localhost";
    // $username_db = "root";
    // $password_db = "";
    // $dbname = "pregnentdb";

    // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    // if ($conn->connect_error) {
    //     die("Connection failed: " . $conn->connect_error);
    // }

    // Query to fetch all patient details
    $sql = "SELECT username, firstname, dp FROM addpatient";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        
        // Fetch the data
        $patientList = array();

        while ($row = $result->fetch_assoc()) {
            $profileImage = $row['dp'];

            
            $binaryData = file_get_contents($profileImage);
            header('Content-Type: image/jpeg');
            $row['dp'] = $binaryData;
            
            $patientList[] = $row;
        }
        // Convert the array to a JSON string
        $response = json_encode($patientList);
        echo $response;
    } else {
        // No patients found
        $response['status'] = 'failure';
        $response['message'] = 'No patients found';
        echo json_encode($response);
    }

    // Close the database connection
    $conn->close();
}