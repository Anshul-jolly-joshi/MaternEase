<?php

require("conn.php");

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check DB connection
if ($conn->connect_error) {
    die(json_encode(["status" => "false", "message" => "Connection failed: " . $conn->connect_error]));
}

$target_dir = "uploads/";
$allowed_extensions = array("mp3", "wav", "ogg");

$additionalData = isset($_POST['additional_data']) ? $_POST['additional_data'] : '';

if (isset($_FILES["audio"]["name"])) {

    $filename = $_FILES["audio"]["name"];
    $filesize = $_FILES["audio"]["size"];
    $temp_name = $_FILES["audio"]["tmp_name"];
    $error = $_FILES["audio"]["error"];

    if ($error !== UPLOAD_ERR_OK) {
        echo json_encode(["status" => "false", "message" => "Error uploading file", "error_code" => $error]);
    } else {
        $file_ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (!in_array($file_ext, $allowed_extensions)) {
            echo json_encode(["status" => "false", "message" => "Invalid file type. Allowed: " . implode(', ', $allowed_extensions)]);
        } elseif ($filesize > 50000000) {
            echo json_encode(["status" => "false", "message" => "File size exceeds limit of 50MB."]);
        } else {

            $new_filename = uniqid() . "." . $file_ext;

            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }

            if (move_uploaded_file($temp_name, $target_dir . $new_filename)) {
                $filepath = $target_dir . $new_filename;
                
                // Prepare statement to avoid SQL injection
                $stmt = $conn->prepare("INSERT INTO audios (filename, filepath, uploaded_at) VALUES (?, ?, CURRENT_TIMESTAMP)");
                $stmt->bind_param("ss", $additionalData, $filepath);

                if ($stmt->execute()) {
                    echo json_encode([
                        "status" => "true",
                        "message" => "File uploaded successfully.",
                        "data" => [
                            "filename" => $additionalData,
                            "filepath" => $filepath
                        ]
                    ]);
                } else {
                    echo json_encode(["status" => "false", "message" => "Database error", "error" => $stmt->error]);
                }
                $stmt->close();
            } else {
                echo json_encode(["status" => "false", "message" => "Error moving uploaded file."]);
            }
        }
    }
} else {
    echo json_encode(["status" => "false", "message" => "No file selected."]);
}

$conn->close();
?>

