<?php
header("Content-Type: application/json");

// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pregnentdb";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(["status" => false, "message" => "Database connection failed"]);
    exit;
}

// Get user question
$question = strtolower(trim($_POST["qns"] ?? "hello"));

// Greetings list
$greetings = ['hi', 'hello', 'hlo', 'hii'];

// Allowed keywords (for postpartum relevance)
$allowed_keywords = ['postpartum', 'post pregnancy', 'post-partum', 'after delivery', 'after childbirth', 'newborn care', 'mother recovery', 'breastfeeding', 'c-section recovery', 'postnatal', 'postnatal care', 'precaution'];

// If greeting, return greeting response
if (in_array($question, $greetings)) {
    echo json_encode([
        "status" => true,
        "data" => [
            ["answer" => "Hi! You can ask me about postpartum health care, precautions, or recovery tips."]
        ]
    ]);
    exit;
}

// Check if question is related to postpartum
$relevant = false;
foreach ($allowed_keywords as $keyword) {
    if (strpos($question, $keyword) !== false) {
        $relevant = true;
        break;
    }
}

// If not relevant, politely decline
if (!$relevant) {
    echo json_encode([
        "status" => false,
        "message" => "I can provide only postpartum or post-pregnancy health-related information."
    ]);
    exit;
}

// Correct Ollama path
$ollama_path = "/opt/homebrew/bin/ollama"; // Update if necessary

// Create smart prompt
if (strpos($question, 'precaution') !== false) {
    // If user mentioned 'precaution', focus on precaution
    $prompt = "In 2-3 short lines, give a postpartum or post-pregnancy health precaution related to: \"$question\".";
} else {
    // Otherwise, give general short description
    $prompt = "In 2-3 short lines, explain about postpartum or post-pregnancy health based on: \"$question\".";
}

// Execute AI Command
$escaped_prompt = escapeshellarg($prompt);
$command = "$ollama_path run mistral $escaped_prompt";
$output = shell_exec($command);
$response = trim($output);

// Handle AI failure
if (!$response) {
    echo json_encode(["status" => false, "message" => "Ollama did not return a response."]);
    exit;
}

// Save question and response into database
$stmt = $conn->prepare("INSERT INTO chat_history (user_question, ai_response) VALUES (?, ?)");
$stmt->bind_param("ss", $question, $response);
$stmt->execute();
$stmt->close();

// Return response
echo json_encode([
    "status" => true,
    "data" => [
        ["answer" => $response]
    ]
]);

$conn->close();
?>

