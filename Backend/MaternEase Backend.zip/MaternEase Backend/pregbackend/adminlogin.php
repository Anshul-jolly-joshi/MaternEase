<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];
        
        require("conn.php");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to check login credentials
        $sql = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Login successful
            $row = $result->fetch_assoc();
            $response = [
                "status" => "true",
                "message" => "Login successful",
                "data" => [
                    [
                        "admin_id" => $row['sno'],  // or change to your actual primary key column
                        "username" => $row['username']
                    ]
                ]
            ];
        } else {
            // Login failed
            $response = [
                "status" => "false",
                "message" => "Invalid username or password",
                "data" => []
            ];
        }

        $conn->close();
    } else {
        $response = [
            "status" => "false",
            "message" => "Username or password not provided",
            "data" => []
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($response);
}
?>

