<?php
require("conn.php");

// Check connection
if ($conn->connect_error) {
    $response = [
        "status" => false,
        "message" => "Connection failed: " . $conn->connect_error,
        "data" => []
    ];
    echo json_encode($response);
    exit();
}

// Get video ID from the POST data
$id = $_POST['id'];

// Fetch filepath and filename from the database based on the id
$sql = "SELECT filepath, filename FROM audios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    $response = [
        "status" => true,
        "message" => "Video found",
        "data" => [
            [
                "filepath" => $row['filepath'],
                "filename" => $row['filename']
            ]
        ]
    ];
} else {
    $response = [
        "status" => false,
        "message" => "Video not found for the given ID",
        "data" => []
    ];
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>

