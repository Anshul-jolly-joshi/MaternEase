<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check if required fields are set
    if (isset($_POST["name"]) && isset($_POST["contact"]) && isset($_POST["age"]) && isset($_POST["gender"]) && isset($_POST["specialist"])) {
        $name = $_POST["name"];
        $contact = $_POST["contact"];
        $age = $_POST["age"];
        $gender = $_POST["gender"];
        $specialist = $_POST["specialist"];
        
        require("conn.php");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Insert query
        $sql = "INSERT INTO dlogin (name, contact, age, gender, specialist)
                VALUES ('$name', '$contact', '$age', '$gender', '$specialist')";
       
        $a = $conn->query($sql);
        
        if ($a === TRUE ) {
            // Return the inserted ID if needed
            $last_id = $conn->insert_id;
            $response = [
                "status" => "true",
                "message" => "Data inserted successfully",
                "data" => [
                    [
                        "insertedId" => $last_id
                    ]
                ]
            ];
        } else {
            $response = [
                "status" => "false",
                "message" => "Data insertion failed",
                "data" => []
            ];
        }

        $conn->close();
    } else {
        // Adjust the response when required fields are missing
        $response = [
            "status" => "false",
            "message" => "Required fields are missing. Please ensure all fields are provided.",
            "data" => []
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($response);
}
?>

