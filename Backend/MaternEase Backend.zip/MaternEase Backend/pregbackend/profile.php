<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"])) {
        $username = $_POST["username"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        // $servername = "localhost";
        // $username_db = "root";
        // $password_db = "";
        // $dbname = "pregnentdb";

        // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        // if ($conn->connect_error) {
        //     die("Connection failed: " . $conn->connect_error);
        // }

        // Query to check login credentials
        $sql = "SELECT firstname, username, dp  FROM addpatient WHERE username = '$username'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch the data
            $row = $result->fetch_assoc();
            $profileImage = $row['dp'];
            

            if(!empty($profileImage) && file_exists($profileImage)){
                $base64Image = base64_encode(file_get_contents($profileImage));
                $response['profileimage'] = $base64Image;
            }else{
                $response['profileimage'] = '';
            }

            // Extract the values you need and concatenate them into a string
            $string_data = $row['firstname'] . ', ' . $row['username'] . ', ' . $base64Image . ', ' . "hi";

            // Login successful
        
            $response = $string_data;
        }else {
            $response['status'] = 'failure';
            $response['message'] = 'Username or password not provided';
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Username or password not provided';
    }

    echo json_encode($response);
}