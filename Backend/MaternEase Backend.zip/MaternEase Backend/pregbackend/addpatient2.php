<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"]) && isset($_POST["noc"])){ // Check for the presence of "username" in $data
        $lmp = date("Y-m-d", strtotime($_POST["lmp"]));
        $edd = date("Y-m-d", strtotime($_POST["edd"]));
        $ga = $_POST["ga"];
        $noc = $_POST["noc"];
        $username =  $_POST["username"];

        // Establish the database connection
        $servername = "localhost";
        $username_db = "root";
        $password_db = "";
        $dbname = "pregnentdb";

        $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to insert data into the database
        $sql = "UPDATE addpatient SET lmp = '$lmp', edd = '$edd' , ga = '$ga' , noofchildren = '$noc' WHERE username = '$username'";

        if (mysqli_query($conn, $sql)) {
            $response['status'] = 'success';
            $response['message'] = 'Data inserted successfully';
        } else {
            $response['status'] = 'failure';
            $response['error'] = $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Username not provided';
    }

    echo json_encode($response);
}
?>
