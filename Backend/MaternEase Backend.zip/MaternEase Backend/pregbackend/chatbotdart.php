<?php

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["qns"])) {
        $qns = $data["qns"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        // $servername = "localhost";
        // $username_db = "root";
        // $password_db = "";
        // $dbname = "pregnentdb";

        // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        if ($conn->connect_error) {
            $response['status'] = 'error';
            $response['message'] = 'Database connection failed';
        } else {
            // Query to check login credentials
            $sql = "SELECT ans FROM questions WHERE qns = '$qns'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Fetch the data
                $row = $result->fetch_assoc();

                // Extract the values you need and concatenate them into a string
                $response['status'] = 'success';
                $response['data'] = $row['ans'];
            } else {
                // No data found
                $response['status'] = 'success';
                $response['data'] = '';
            }

            // Close the database connection
            $conn->close();
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Parameter "qns" not provided';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method';
}

echo json_encode($response);
