<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
require("conn.php");

// Check connection
if ($conn->connect_error) {
    die(json_encode(["status" => "false", "message" => "Connection failed: " . $conn->connect_error]));
}

$uploadDir = "videos/";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['uploaded_file'])) {
    
    $file = $_FILES['uploaded_file'];
    $filename = isset($_POST['video_title']) && $_POST['video_title'] !== '' ? $_POST['video_title'] : pathinfo($file['name'], PATHINFO_FILENAME);
    
    $fileName = basename($file['name']);
    $uploadPath = $uploadDir . $fileName;
    
    // Create directory if not exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        
        // Prepared statement to prevent SQL injection
        $sql = "INSERT INTO pregvideo (video_title, video_one) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("ss", $filename, $uploadPath);

            if ($stmt->execute()) {
                echo json_encode([
                    "status" => "true",
                    "message" => "Video uploaded and path inserted successfully",
                    "data" => [
                        "video_title" => $filename,
                        "video_path" => $uploadPath
                    ]
                ]);
            } else {
                echo json_encode(["status" => "false", "message" => "Database insert failed", "error" => $stmt->error]);
            }
            $stmt->close();
        } else {
            echo json_encode(["status" => "false", "message" => "Prepare failed", "error" => $conn->error]);
        }

    } else {
        echo json_encode(["status" => "false", "message" => "File upload failed"]);
    }
} else {
    echo json_encode(["status" => "false", "message" => "Invalid request or file missing"]);
}

// Close connection
$conn->close();
?>

