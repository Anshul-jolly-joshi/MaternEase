<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if required fields are provided
    if (isset($_POST["username"]) && isset($_POST["old_password"]) && isset($_POST["new_password"])) {
        $username = $_POST["username"];
        $old_password = $_POST["old_password"];
        $new_password = $_POST["new_password"];

        // Establish the database connection
        require("conn.php");

        if ($conn->connect_error) {
            die(json_encode(["status" => "false", "message" => "Database connection failed", "data" => []]));
        }

        // Query to check if the username and old password match
        $sql = "SELECT sno FROM addpatient WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $old_password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $userId = $row['sno'];

            // Update the password
            $update_sql = "UPDATE addpatient SET password = ? WHERE username = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ss", $new_password, $username);
            
            if ($update_stmt->execute()) {
                echo json_encode([
                    "status" => "true",
                    "message" => "Password updated successfully",
                    "data" => [["userId" => $userId]]
                ]);
            } else {
                echo json_encode(["status" => "false", "message" => "Failed to update password", "data" => []]);
            }
            
        } else {
            echo json_encode(["status" => "false", "message" => "Invalid username or old password", "data" => []]);
        }

        // Close database connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode(["status" => "false", "message" => "Required fields missing", "data" => []]);
    }
}
?>
