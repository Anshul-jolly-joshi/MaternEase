<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["username"]) && isset($_POST["password"])){
        $username = $_POST["username"];
        $password = $_POST["password"];
        $name = $_POST["name"];
        $age = $_POST["age"];
        $gender = $_POST["gender"];
        $contact = $_POST["contact"];
        $specialist = $_POST["specialist"];
        
        require("conn.php");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Insert query
        $sql = "INSERT INTO dlogin (username, password, name, contact, age, gender, specialist)
                VALUES ('$username', '$password', '$name', '$contact', '$age', '$gender', '$specialist')";
       
        $a = $conn->query($sql);
        
        if ($a === TRUE ) {
            // You can return the ID of the inserted row if needed
            $last_id = $conn->insert_id;
            $response = [
                "status" => "true",
                "message" => "Data inserted successfully",
                "data" => [
                    [
                        "insertedId" => $last_id
                    ]
                ]
            ];
        } else {
            $response = [
                "status" => "false",
                "message" => "Data insertion failed",
                "data" => []
            ];
        }

        $conn->close();
    } else {
        $response = [
            "status" => "false",
            "message" => "Required fields are missing",
            "data" => []
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($response);
}
?>

