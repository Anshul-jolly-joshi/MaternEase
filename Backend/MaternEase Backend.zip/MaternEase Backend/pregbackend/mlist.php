<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish the database connection
    require("conn.php");

    // Check connection
    if ($conn->connect_error) {
        die(json_encode([
            "status" => false,
            "message" => "Database connection failed"
        ]));
    }

    // Query to fetch all video details
    $sql = "SELECT vid, video_title, video_one FROM meditation";
    $result = $conn->query($sql);

    // Prepare response structure
    $response = [
        "status" => false, // Default status
        "message" => "No videos found",
        "data" => []
    ];

    if ($result->num_rows > 0) {
        // Fetch the data
        while ($row = $result->fetch_assoc()) {
            $response["data"][] = $row;
        }

        // Update success status and message
        $response["status"] = true;
        $response["message"] = "Data retrieved successfully";
    }

    // Output response as JSON
    echo json_encode($response, JSON_PRETTY_PRINT);

    // Close the database connection
    $conn->close();
}
?>

